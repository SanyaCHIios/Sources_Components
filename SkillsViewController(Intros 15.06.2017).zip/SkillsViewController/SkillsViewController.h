#import <UIKit/UIKit.h>
@interface SkillsViewController : UIView

//! set this prameters only befor call setter for data source!
@property (assign, nonatomic) BOOL isEditing;
@property (assign, nonatomic) NSUInteger aligment;//0 - center, 1 - left, 2 - right
@property (assign, nonatomic) IBInspectable NSUInteger space;
//!

@property (strong, nonatomic) NSArray *dataSource;
@property (copy, nonatomic) void (^removeBlock)(SkillsViewController *control, NSUInteger Index);

- (void)relodUI;

@end
