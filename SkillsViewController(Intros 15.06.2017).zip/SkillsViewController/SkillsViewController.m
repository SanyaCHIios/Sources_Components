#import "SkillsViewController.h"
#import "Constants.h"

@interface SkillsViewController ()
@property (strong, nonatomic) NSMutableArray<UIView *>* existViews;
@end

@implementation SkillsViewController

- (void)setDataSource:(NSArray *)dataSource {
    _dataSource = dataSource;
    [self updateUI];
}

- (void)relodUI {
    [self updateUI];
}

- (void)updateUI {
    CGFloat width = CGRectGetWidth([UIScreen mainScreen].bounds) - self.space;
    
    CGFloat minSize = [self minFontSizeFromSize:12*[DataCommon screenKoef]];
    UIFont *defFont = [UIFont systemFontOfSize:minSize];
    
    CGFloat firstSize = 0;
    CGFloat secondSize = 0;
    
    CGFloat space_x = 5;
    CGFloat space_y = 3;
    
    for (UIView *subv in self.subviews) {
        [subv removeFromSuperview];
    }
    
    if (self.dataSource.count >= 1)
        firstSize = [self sizeItem:[self.dataSource firstObject] withFont:defFont];
    if (self.dataSource.count == 2)
        secondSize = [self sizeItem:[self.dataSource lastObject] withFont:defFont];
    
    CGFloat allWidth = firstSize + secondSize + space_x;
    CGFloat first_X = (width - allWidth)/2;
    
    if (allWidth > width) {
        
        CGFloat half = width/2 - space_x;
        first_X = 0;
        
        if (firstSize > secondSize) {
            if (secondSize < half) {
                firstSize = half + (half-secondSize);
            }
        } else if (firstSize < secondSize) {
            if (firstSize < half) {
                secondSize = half + (half-firstSize);
            }
        } else {
            firstSize = half;
            secondSize = firstSize;
        }
    }
    
    if (self.aligment == 1) {
        first_X = 0;
    }
    
    if (self.aligment == 2) {
        first_X = (width - allWidth);
    }
    if (secondSize > 0) {
        UIView *firstConteiner = [self skillForIndex:0 frame:CGRectMake(first_X, 3, firstSize, CGRectGetHeight(self.frame) - space_y*2) text:[self.dataSource firstObject] font:defFont];
        [self addSubview:firstConteiner];
        
        [self addSubview:[self skillForIndex:1 frame:CGRectMake(CGRectGetMaxX(firstConteiner.frame) + space_x, space_y, secondSize, CGRectGetHeight(self.frame) - space_y*2) text:[self.dataSource lastObject] font:defFont]];
        
    } else if (firstSize > 0){
        CGFloat first_X = width/2 - firstSize/2;
        
        if (self.aligment == 1) {
            first_X = 0;
        }
        if (self.aligment == 2) {
            first_X = (width - firstSize);
        }

        UIView *firstConteiner = [self skillForIndex:0 frame:CGRectMake(first_X, 0, firstSize, CGRectGetHeight(self.frame) - space_y*2) text:[self.dataSource firstObject] font:defFont];
        [self addSubview:firstConteiner];
    }
}

- (UIView *)skillForIndex:(NSUInteger)index
                    frame:(CGRect)frame
                     text:(NSString *)text
                     font:(UIFont *)font {
    
    UIView *conteiner = [[UIView alloc] initWithFrame:frame];
    conteiner.backgroundColor = [DataCommon lightBlueColor];
    conteiner.layer.cornerRadius = 3;
    CGFloat sapace = (10*[DataCommon screenKoef])*2;
    
    UILabel *infoLabel = [[UILabel alloc] initWithFrame:CGRectMake(10*[DataCommon screenKoef], 0, CGRectGetWidth(conteiner.frame) - sapace, CGRectGetHeight(conteiner.frame))];
    
    infoLabel.font = font;
    infoLabel.text = text;
    infoLabel.textColor = [UIColor whiteColor];
    [conteiner addSubview:infoLabel];
    
    if (self.isEditing) {
        UIButton *firstButton = [UIButton buttonWithType:UIButtonTypeCustom];
        firstButton.frame = CGRectMake(0, 0, CGRectGetWidth(conteiner.frame), CGRectGetHeight(conteiner.frame));
        firstButton.tag = index;
        firstButton.titleLabel.font = [UIFont systemFontOfSize:12];
        
        CGFloat inset = CGRectGetHeight(conteiner.frame);
        
        firstButton.imageEdgeInsets = UIEdgeInsetsMake(0, infoLabel.frame.size.width-(inset*[DataCommon screenKoef]+4),
                                                       0, -inset);
        
        [firstButton setImage:[UIImage imageNamed:@"DeleteSkilsIcon"] forState:UIControlStateNormal];
        [firstButton addTarget:self action:@selector(deleteAction:) forControlEvents:UIControlEventTouchUpInside];

        [conteiner addSubview:firstButton];
    }
    
    return conteiner;
}

- (CGFloat)sizeItem:(NSString *)itemText withFont:(UIFont *)font {
    CGFloat size = 0;
    
    CGFloat inset = CGRectGetHeight(self.frame)-font.pointSize;
    CGFloat butH = self.isEditing ? inset*[DataCommon screenKoef] : 15*[DataCommon screenKoef];
    
    CGRect rect = [itemText boundingRectWithSize:CGSizeMake(CGFLOAT_MAX, self.frame.size.height) options:NSLineBreakByWordWrapping | NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:font} context:nil];
    size = rect.size.width + font.pointSize/2;
    
    return size + butH;
}

- (CGFloat)minFontSizeFromSize:(CGFloat)size {
    CGFloat width = CGRectGetWidth([UIScreen mainScreen].bounds) - self.space;
    UIFont *defFont = [UIFont systemFontOfSize:size];
    CGFloat contentHeight = 0;
    
    CGFloat butH = self.isEditing ? 30*[DataCommon screenKoef] : 15*[DataCommon screenKoef];
    
    for (NSString *text in self.dataSource) {
        CGRect rect = [text boundingRectWithSize:CGSizeMake(CGFLOAT_MAX, self.frame.size.height) options:NSLineBreakByWordWrapping | NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:defFont} context:nil];
        contentHeight += rect.size.width + defFont.pointSize/2+butH;
    }
    
    if (contentHeight > width && size > 7) {
        return [self minFontSizeFromSize:size-1];
    }
    
    return size;
}

#pragma mark - Action

- (void)deleteAction:(UIButton *)but {
    if (self.removeBlock) {
        self.removeBlock(self, but.tag);
    }
}

@end
