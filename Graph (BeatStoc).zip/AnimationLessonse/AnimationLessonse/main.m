//
//  main.m
//  AnimationLessonse
//
//  Created by green on 13.06.17.
//  Copyright © 2017 green. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
