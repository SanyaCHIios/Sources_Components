//
//  AppDelegate.h
//  AnimationLessonse
//
//  Created by green on 13.06.17.
//  Copyright © 2017 green. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

