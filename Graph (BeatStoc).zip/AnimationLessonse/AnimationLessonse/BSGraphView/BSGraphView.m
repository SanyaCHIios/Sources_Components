//
//  BSGraphView.m
//  AnimationLessonse
//
//  Created by green on 13.06.17.
//  Copyright © 2017 green. All rights reserved.
//

#import "BSGraphView.h"
#import "GraphPoint.h"

#define MAX_COUNT 60

#define TOP_INSET 20
#define BOTTOM_INSET 5

@interface BSGraphView ()

@property (strong, nonatomic) NSArray *dataSource;
@property (strong, nonatomic) NSArray *convertedPoints;
@property (strong, nonatomic) NSArray *sourceArr;

@property (strong, nonatomic) NSDate *fromDate;
@property (strong, nonatomic) NSDate *toDate;

@property (assign, nonatomic) CGFloat min;
@property (assign, nonatomic) CGFloat max;

@property (assign, nonatomic) BOOL isValueChangeMode;
@property (assign, nonatomic) CGPoint fingerPoint;

@property (strong, nonatomic) UIView *pointerView;
@property (strong, nonatomic) UIView *pointView;
@property (strong, nonatomic) UILabel *infLabel;

@end

@implementation BSGraphView

+ (BSGraphView *)addGraphToView:(UIView *)view
                       fromRect:(CGRect)rect
                         source:(NSArray *)source
                      animation:(BOOL)animation {
    
    BSGraphView *graphView = [[BSGraphView alloc] initWithFrame:rect];
    
    NSDate *date = [NSDate date];
    graphView.fromDate = [NSDate dateWithTimeIntervalSince1970:([date timeIntervalSince1970]-(15*25*60))];
    graphView.toDate = [NSDate dateWithTimeIntervalSince1970:([date timeIntervalSince1970]+(15*25*60))];
    
    graphView.sourceArr = [graphView genericDataSource];
    
    if (animation) {
        graphView.frame = CGRectMake(0, CGRectGetHeight(rect), CGRectGetWidth(rect), 2);
        graphView.alpha = 0.5f;
        
        [view addSubview:graphView];
        
        [graphView reloadGraphSource];
        
        [UIView animateWithDuration:0.3 delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
            
            graphView.frame = CGRectMake(0, 0, CGRectGetWidth(rect), CGRectGetHeight(rect));
            graphView.alpha = 1.0f;
            
            [graphView reloadGraphSource];
        } completion:^(BOOL finished) {
            //!
        }];
    } else {
        [view addSubview:graphView];
        [graphView reloadGraphSource];
    }
    
    return graphView;
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(nullable UIEvent *)event {
    self.isValueChangeMode = YES;
    
    UITouch *touch = [[event allTouches] anyObject];
    CGPoint touchLocation = [touch locationInView:self];
    
    self.fingerPoint = touchLocation;
    CGPoint vPoint = CGPointZero;
    GraphPoint *pp = nil;
    
    if (self.pointerView)
        vPoint = CGPointMake(self.pointerView.center.x, self.pointerView.center.y);
    
    for (GraphPoint *point in self.dataSource) {
        vPoint = [self pointForGrafPoint:point];
        CGPoint vPointNext = vPoint;
       
        if ([self.dataSource indexOfObject:point]+1 < self.dataSource.count) {
            vPointNext = [self pointForGrafPoint:[self.dataSource objectAtIndex:[self.dataSource indexOfObject:point]+1]];
        }
        if (ceil(self.fingerPoint.x) >= ceil(vPoint.x) && ceil(self.fingerPoint.x) < vPointNext.x) {
            NSLog(@"\nVALUE : %@ - POINT : %@", @(point.value), @(vPoint.y));
            pp = point;
            break;
        }
    }
    if (self.pointerView == nil) {
        
        self.pointerView = [[UIView alloc] initWithFrame:CGRectMake(vPoint.x-25, 0, 50, CGRectGetHeight(self.frame))];
        
        //! info line
        self.infLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 50, TOP_INSET)];
        self.infLabel.textAlignment = NSTextAlignmentCenter;
        self.infLabel.textColor = [UIColor colorWithRed:105.0/255.0 green:106.0/255.0 blue:108.0/255.0 alpha:0.8];
        self.infLabel.font = [UIFont systemFontOfSize:14];
        self.infLabel.text = @(pp.value).stringValue;
        
        [self.pointerView addSubview:self.infLabel];
        
        //! gray line
        UIView *gLine = [[UIView alloc] initWithFrame:CGRectMake(0, TOP_INSET, 1, CGRectGetHeight(self.frame)-TOP_INSET)];
        gLine.center = CGPointMake(CGRectGetWidth(self.pointerView.frame)/2,
                                   CGRectGetHeight(self.pointerView.frame)/2+TOP_INSET/2);
        
        gLine.backgroundColor = [UIColor colorWithRed:105.0/255.0 green:106.0/255.0 blue:108.0/255.0 alpha:0.8];
        
        [self.pointerView addSubview:gLine];
        
        //! dot
        self.pointView = [[UIView alloc] initWithFrame:CGRectMake(CGRectGetWidth(self.pointerView.frame)/2, vPoint.y, 5,5)];
        self.pointView.layer.cornerRadius = 2.5f;
        self.pointView.layer.shadowColor = [UIColor colorWithRed:58.0/255.0 green:220.0/255.0 blue:140.0/255.0 alpha:1.0].CGColor;
        UIBezierPath *shadowPath = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(-5, -2.5, CGRectGetWidth(self.pointView.frame)+10, CGRectGetHeight(self.pointView.frame)+10) cornerRadius:10];
        
        self.pointView.layer.shadowPath = shadowPath.CGPath;
        self.pointView.layer.shadowOpacity = 0.5;

        self.pointView.backgroundColor = [UIColor whiteColor];
        
        [self.pointerView addSubview:self.pointView];
        
        self.pointerView.alpha = 0;
        [self addSubview:self.pointerView];
        
        //! anim
        [UIView animateWithDuration:0.35 animations:^{
             self.pointerView.alpha = 1;
        }];
    }
    //!
    self.pointerView.center = CGPointMake(vPoint.x, CGRectGetHeight(self.frame)/2);
    self.pointView.center = CGPointMake(CGRectGetWidth(self.pointerView.frame)/2, vPoint.y);
    self.infLabel.text = @(pp.value).stringValue;
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(nullable UIEvent *)event {
    self.isValueChangeMode = NO;
    //! anim
    [UIView animateWithDuration:0.35 animations:^{
        self.pointerView.alpha = 0;
    }completion:^(BOOL finished) {
        [self.pointerView removeFromSuperview];
        self.pointerView = nil;
    }];
}

#pragma maprk - Reload Graph

- (void)reloadGraphSource {
    if (self.dataSource == nil)
        self.dataSource = [self visibleSource];//[self genericDataSource];

    for (GraphPoint *point in self.dataSource) {
        if (point.value < self.min) {
            self.min = point.value;
        }
        
        if (point.value > self.max) {
            self.max = point.value;
        }
        NSDate *date = [NSDate date];
        
//        self.fromDate = [NSDate dateWithTimeIntervalSince1970:([date timeIntervalSince1970]-(15*25*60))];
//        self.toDate = [NSDate dateWithTimeIntervalSince1970:([date timeIntervalSince1970]+(15*25*60))];
        
//        if (self.fromDate == nil || [self.fromDate timeIntervalSince1970] > [point.timeStamp timeIntervalSince1970]) {
//            self.fromDate = point.timeStamp;
//        }
//        
//        if (self.toDate == nil || [self.toDate timeIntervalSince1970] < [point.timeStamp timeIntervalSince1970]) {
//            self.toDate = point.timeStamp;
//        }
    }
    
    [self setNeedsDisplay];
}

#pragma mark - Draw Graph

- (void)drawRect:(CGRect)rect {
    [super drawRect:rect];
    
    CGContextRef context = UIGraphicsGetCurrentContext();

    CGContextSetRGBFillColor(context,  255.0/255.0, 255.0/255.0, 255.0/255.0, 0.7);
    CGContextSetLineWidth(context, 1.0);
    
    CGFloat startYPoint = CGRectGetHeight(self.graphRect) - (CGRectGetHeight(self.graphRect)/(self.max + ABS(self.min))) * ABS(self.min);
    startYPoint+=20;
    
    CGFloat dotYPoint = CGRectGetHeight(self.frame)/2;
    
    if (CGRectGetHeight(self.bounds) > 2)
        dotYPoint = startYPoint;
    
    for (int i = 0; i < MAX_COUNT; i++) {
        
        CGContextAddEllipseInRect(context,(CGRectMake((CGRectGetWidth(self.frame)/MAX_COUNT)*i, dotYPoint, 1.0, 1.0)));
        CGContextDrawPath(context, kCGPathFill);
    }
    
    CGContextStrokePath(context);
    
    if (CGRectGetHeight(self.bounds) == 2)
        [[UIColor clearColor] setStroke];
    else
        [[UIColor colorWithRed:58.0/255.0 green:220.0/255.0 blue:140.0/255.0 alpha:1.0] setStroke];
    
    UIBezierPath *grathPath = [UIBezierPath bezierPath];
    
    GraphPoint *pointTT = self.dataSource.firstObject;
    CGPoint point_f = [self pointForGrafPoint:pointTT];
    
    [grathPath moveToPoint:CGPointMake(0.0, point_f.y)];
    
    
    for (GraphPoint *point in self.dataSource) {
        CGPoint pointw = [self pointForGrafPoint:point];
        
        NSLog(@"POINT : %@, %@", @(pointw.x), @(pointw.y));
        [grathPath addLineToPoint:pointw];
    }
    [grathPath stroke];
    
    if (CGRectGetHeight(self.bounds) > 2) {
        UIBezierPath *clipPath = grathPath.copy;
        CGPoint pointl = [self pointForGrafPoint:[self.dataSource lastObject]];
        
        [clipPath addLineToPoint:CGPointMake(pointl.x, CGRectGetHeight(self.frame))];
        [clipPath addLineToPoint:CGPointMake(0, CGRectGetHeight(self.frame))];
        
        CGPoint pointf = [self pointForGrafPoint:[self.dataSource firstObject]];

        
        [clipPath addLineToPoint:pointf];
        [clipPath closePath];
        [clipPath addClip];
        

        CGColorSpaceRef rgb = CGColorSpaceCreateDeviceRGB();

        CGFloat colors[] = {
            58.0/255.0, 220.0/255.0, 140.0/255.0, 0.7,
            58.0/255.0, 220.0/255.0, 140.0/255.0, 0.3,
            58.0/255.0, 220.0/255.0, 140.0/255.0, 0.0,
        };
        
        CGGradientRef gradient = CGGradientCreateWithColorComponents(rgb, colors, NULL, sizeof(colors)/(sizeof(colors[0])*4));
        
        CGPoint startPoint = CGPointMake(CGRectGetMidX(rect), CGRectGetMinY(rect));
        CGPoint endPoint = CGPointMake(CGRectGetMidX(rect), CGRectGetMaxY(rect));
        CGContextDrawLinearGradient(context, gradient, startPoint, endPoint, kCGGradientDrawsBeforeStartLocation);
    }
}

#pragma mark - Helper

- (CGPoint)pointForGrafPoint:(GraphPoint *)point {

    CGFloat xP = (CGRectGetWidth(self.frame)/((self.toDate.timeIntervalSince1970 - self.fromDate.timeIntervalSince1970)/self.dataSource.count)) * ((point.timeStamp.timeIntervalSince1970 - self.fromDate.timeIntervalSince1970)/self.dataSource.count);
    if (xP < 0) {
        
    }
    CGFloat yP = 0;
    if (point.value > 0) {
        yP = CGRectGetHeight(self.graphRect) - (CGRectGetHeight(self.graphRect)/(self.max + ABS(self.min)) *(ABS(point.value) + ABS(self.min)));
    }
    if (point.value < 0) {
        yP = CGRectGetHeight(self.graphRect) - CGRectGetHeight(self.graphRect)/(self.max + ABS(self.min)) * ABS(ABS(self.min) - ABS(point.value));
    }
    if (point.value == 0) {
        yP = CGRectGetHeight(self.graphRect) - (CGRectGetHeight(self.graphRect)/(self.max + ABS(self.min))) * ABS(self.min);
    }
    
    //! top inset correction
    yP+=TOP_INSET;
    
    return CGPointMake(xP, yP);
}

- (CGRect)graphRect {
    return CGRectMake(0, TOP_INSET, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame)-(TOP_INSET+BOTTOM_INSET));
}



#pragma mark - Test

- (NSArray *)genericDataSource {
    NSDate *date = [NSDate date];
    NSInteger min = -10;
    
    NSMutableArray *arr = [NSMutableArray new];
    
    for (int i = 0; i < 10;i++) {
        GraphPoint *point = [GraphPoint new];
        point.timeStamp = [NSDate dateWithTimeIntervalSince1970:([date timeIntervalSince1970]+(15*i*60))];
        
        point.value = min+(NSInteger)rand()%30;
        
        if (i == 80) {
            point.value = 40;
        }
        if (i > 80)
            point.value = 52;
        if (i%30 == 0)
            point.value = -10;
        
        [arr addObject:point];
    }
    
    return arr;
}

- (NSArray *)visibleSource {
    NSMutableArray *splitedArray = [NSMutableArray new];
    if (self.sourceArr.count < MAX_COUNT) {
        
        GraphPoint *first = [GraphPoint new];
        GraphPoint *last = [GraphPoint new];
        
        first.value = [(GraphPoint*)[self.sourceArr firstObject] value];
        first.timeStamp = self.fromDate;
        
        last.value = [(GraphPoint*)[self.sourceArr lastObject] value];
        last.timeStamp = self.toDate;
        
        [splitedArray addObject:first];
        [splitedArray addObjectsFromArray:self.sourceArr];
        [splitedArray addObject:last];
        
    } else {
        splitedArray = self.sourceArr.mutableCopy;
    }
    
    return splitedArray;
}

@end
