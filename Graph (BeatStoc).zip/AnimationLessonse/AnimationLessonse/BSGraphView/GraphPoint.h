#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface GraphPoint : NSObject

@property (assign, nonatomic) CGFloat value;
@property (strong, nonatomic) NSDate *timeStamp;

@end
