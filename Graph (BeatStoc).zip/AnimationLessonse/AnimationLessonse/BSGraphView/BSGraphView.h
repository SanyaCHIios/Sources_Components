//
//  BSGraphView.h
//  AnimationLessonse
//
//  Created by green on 13.06.17.
//  Copyright © 2017 green. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BSGraphView : UIView
+ (BSGraphView *)addGraphToView:(UIView *)view
                       fromRect:(CGRect)rect
                         source:(NSArray *)source
                      animation:(BOOL)animation;

//! redraw and reload graph
- (void)reloadGraphSource;
@end
