//
//  ViewController.m
//  AnimationLessonse
//
//  Created by green on 13.06.17.
//  Copyright © 2017 green. All rights reserved.
//

#import "ViewController.h"
#import "BSGraphView.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIView *topGrayView;
@property (weak, nonatomic) IBOutlet UIView *conteinerGraphView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *constraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *con2;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)makeAnimation:(id)sender {
    [self.view layoutIfNeeded];
//    [UIView animateWithDuration:0.35 animations:^{
//        
//        self.constraint.constant = 128;
//        self.con2.constant = 8;
//        
//        [self.graphView reloadGraphSource];
//        [self.view layoutIfNeeded];
//    } completion:^(BOOL finished) {
//        //
//        [self.graphView reloadGraphSource];
//        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//            self.constraint.constant = 2;
//            self.con2.constant = 128;
//            [self.graphView reloadGraphSource];
//        });
//        
//    }];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [BSGraphView addGraphToView:self.conteinerGraphView fromRect:self.conteinerGraphView.frame source:nil animation:YES];
    });
    
}

@end
