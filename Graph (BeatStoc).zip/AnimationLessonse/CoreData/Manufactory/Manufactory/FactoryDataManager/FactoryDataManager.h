
#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@interface FactoryDataManager : NSObject
@property (strong, readonly) NSManagedObjectContext *managedObjectContext;

+ (instancetype)defaultManager;
- (void)initializeCoreData;
- (void)save;
@end
