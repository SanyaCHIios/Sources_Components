//
//  User.m
//  Manufactory
//
//  Created by green on 25.01.17.
//  Copyright © 2017 Quad. All rights reserved.
//

#import "User.h"

@implementation User

- (BOOL)validateValue:(inout id  _Nullable __autoreleasing *)ioValue forKey:(NSString *)inKey error:(out NSError * _Nullable __autoreleasing *)outError {
    
    if ([inKey isEqualToString:@"name"]) {
        *outError = [NSError errorWithDomain:@"com.tt" code:1010 userInfo:@{NSLocalizedDescriptionKey : @"test error"}];
        return NO;
    }
    
    return NO;
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    if (self = [super init]) {
        self.name = [aDecoder decodeObjectForKey:@"name"];
    }
    return self;
}

- (void)encodeWithCoder:(NSCoder *)aCoder {
    [aCoder encodeObject:self.name forKey:@"name"];
}

@end
