//
//  MMigrationPolicy.h
//  Manufactory
//
//  Created by green on 21.02.17.
//  Copyright © 2017 Quad. All rights reserved.
//

#import <CoreData/CoreData.h>

@interface MMigrationPolicy : NSEntityMigrationPolicy

@end
