//
//  MMigrationPolicy.m
//  Manufactory
//
//  Created by green on 21.02.17.
//  Copyright © 2017 Quad. All rights reserved.
//

#import "MMigrationPolicy.h"

@implementation MMigrationPolicy

- (BOOL)createDestinationInstancesForSourceInstance:(NSManagedObject*)source
                                      entityMapping:(NSEntityMapping*)mapping
                                            manager:(NSMigrationManager*)manager
                                              error:(NSError**)error {
    
    NSManagedObjectContext *destMOC = [manager destinationContext];
    NSString *destEntityName = [mapping destinationEntityName];
    NSString *name = [source valueForKey:@"title"];
    
    return YES;
}

- (BOOL)createRelationshipsForDestinationInstance:(NSManagedObject*)dInstance
                                    entityMapping:(NSEntityMapping*)mapping
                                          manager:(NSMigrationManager*)manager
                                            error:(NSError**)error{
    return YES;
}
@end
