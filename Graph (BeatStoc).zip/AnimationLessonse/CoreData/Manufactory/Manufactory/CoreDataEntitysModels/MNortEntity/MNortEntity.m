//
//  MNortEntity.m
//  Manufactory
//
//  Created by green on 21.02.17.
//  Copyright © 2017 Quad. All rights reserved.
//

#import "MNortEntity.h"

@implementation MNortEntity
@dynamic nortID;
@dynamic nortName;
@dynamic mans;
@end
