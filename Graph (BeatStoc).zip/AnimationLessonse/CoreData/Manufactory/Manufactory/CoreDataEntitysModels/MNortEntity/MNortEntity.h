//
//  MNortEntity.h
//  Manufactory
//
//  Created by green on 21.02.17.
//  Copyright © 2017 Quad. All rights reserved.
//

#import <CoreData/CoreData.h>
@class MItemEntity;

@interface MNortEntity : NSManagedObject
@property (strong, nonatomic) NSString * nortName;
@property (strong, nonatomic) NSString * nortID;

@property (strong, nonatomic) MItemEntity * mans;
@end
