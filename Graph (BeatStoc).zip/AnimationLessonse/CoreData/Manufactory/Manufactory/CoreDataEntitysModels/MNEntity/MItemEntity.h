//
//  MItemEntity.h
//  Manufactory
//
//  Created by green on 09.02.17.
//  Copyright © 2017 Quad. All rights reserved.
//

#import <CoreData/CoreData.h>
@class MNortEntity;

@interface MItemEntity : NSManagedObject

@property (strong, nonatomic) NSNumber * test;
@property (strong, nonatomic) NSNumber * testId;
@property (strong, nonatomic) NSString * title;
@property (strong, nonatomic) NSNumber * type;

@property (strong, nonatomic) MNortEntity * norts;

@end
