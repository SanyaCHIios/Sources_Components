//
//  MItemEntity.m
//  Manufactory
//
//  Created by green on 09.02.17.
//  Copyright © 2017 Quad. All rights reserved.
//

#import "MItemEntity.h"

@implementation MItemEntity
@dynamic test;
@dynamic testId;
@dynamic type;
@dynamic title;
@dynamic norts;
@end
