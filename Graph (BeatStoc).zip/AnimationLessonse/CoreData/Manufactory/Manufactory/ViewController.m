//
//  ViewController.m
//  Manufactory
//
//  Created by green on 16.12.16.
//  Copyright © 2016 Quad. All rights reserved.
//

#import "ViewController.h"
#import "FactoryDataManager.h"
#import <CoreData/CoreData.h>
#import "MItemEntity.h"
#import "User.h"
#import <objc/runtime.h>
#import <AdSupport/ASIdentifierManager.h>

#import "ManufactoryTableViewCell.h"

#import <ifaddrs.h>
#import <arpa/inet.h>

@interface NSString (DataSet) {
}
@property (nonatomic, retain) NSDate *date;
@end

static void * LaserUnicornsPropertyKey = &LaserUnicornsPropertyKey;

@implementation NSString (DataSet)

- (NSDate *)date {
    return objc_getAssociatedObject(self, LaserUnicornsPropertyKey);
}
- (void)setDate:(NSDate *)date {
    objc_setAssociatedObject(self, LaserUnicornsPropertyKey, date, OBJC_ASSOCIATION_RETAIN);
}

@end

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (weak, nonatomic) IBOutlet UITextField *typeTextField;
@property (weak, nonatomic) IBOutlet UITextField *titleTextField;

@property (nonatomic, strong) UIImageView *imageView;

@property (strong, nonatomic) NSFetchedResultsController *fetchManufactoryController;
@property (nonatomic) dispatch_semaphore_t preloadedLock;
@end

@implementation ViewController

- (void)viewDidLoad {
    
    
    dispatch_queue_t queue_t = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    
    //self.preloadedLock = dispatch_semaphore_create(0);
    //[self nextTTT];
    // dispatch_semaphore_wait(self.preloadedLock, DISPATCH_TIME_FOREVER);
    
    dispatch_sync(queue_t, ^{
        NSLog(@"2");
        dispatch_sync(queue_t, ^{
            NSLog(@"3");
        });
        dispatch_sync(queue_t, ^{
            NSLog(@"4");
        });
        NSLog(@"5");
    });
    //[self nextTTT];
    //dispatch_semaphore_wait(self.preloadedLock, DISPATCH_TIME_FOREVER);
    
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [FactoryDataManager defaultManager];
    //dispatch_semaphore_signal(self.preloadedLock);
    [self applyFetch];
    
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    [center addObserver:self
               selector:@selector(contextUpdated:) name:NSManagedObjectContextDidSaveNotification
                 object:[FactoryDataManager defaultManager].managedObjectContext];
    
    NSString *mac  = [[[ASIdentifierManager sharedManager] advertisingIdentifier] UUIDString];
    NSLog(@"mac address : %@", mac);
    
    [self getIPAddress];
    
}


- (NSString *)getIPAddress {
    NSString *address = @"error";
    struct ifaddrs *interfaces = NULL;
    struct ifaddrs *temp_addr = NULL;
    int success = 0;
    // retrieve the current interfaces - returns 0 on success
    success = getifaddrs(&interfaces);
    if (success == 0) {
        // Loop through linked list of interfaces
        temp_addr = interfaces;
        while(temp_addr != NULL) {
            if(temp_addr->ifa_addr->sa_family == AF_INET) {
                // Check if interface is en0 which is the wifi connection on the iPhone
                if([[NSString stringWithUTF8String:temp_addr->ifa_name] isEqualToString:@"en0"]) {
                    // Get NSString from C String
                    address = [NSString stringWithUTF8String:inet_ntoa(((struct sockaddr_in *)temp_addr->ifa_addr)->sin_addr)];
                }
            }
            temp_addr = temp_addr->ifa_next;
        }
    }
    // Free memory
    freeifaddrs(interfaces);
    return address;
    
}

- (void)contextUpdated:(NSManagedObjectContext *)context {
    
}

- (void)nextTTT {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        dispatch_semaphore_signal(self.preloadedLock);
    });
    //dispatch_semaphore_signal(self.preloadedLock);
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - lazy initial

- (UIImageView *)imageView {
    if (_imageView == nil) {
        _imageView = [[UIImageView alloc] initWithFrame:CGRectMake(50, 50, 100, 100)];
        _imageView.backgroundColor = [UIColor greenColor];
    }
    return _imageView;
}

- (IBAction)saveAction:(id)sender {
 
    MItemEntity *m_manufact = [NSEntityDescription insertNewObjectForEntityForName:@"ManEntity" inManagedObjectContext:[FactoryDataManager defaultManager].managedObjectContext];
    
    m_manufact.testId = @(CACurrentMediaTime());
    m_manufact.type = @(self.typeTextField.text.integerValue);
    m_manufact.title = self.titleTextField.text;
    
    NSError *saveError = nil;
    
    [[FactoryDataManager defaultManager].managedObjectContext save:&saveError];
    
    if (saveError) {
        [self showErrorAlertWith:saveError.localizedDescription];
    } 
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [[self.fetchManufactoryController sections][section] numberOfObjects];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return [[self.fetchManufactoryController sections] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    MItemEntity *m_manufact = [[self.fetchManufactoryController sections][indexPath.section] objects][indexPath.row];
    NSLog(@"entt - > %@ ::: indexPath %@", m_manufact.type, indexPath);
    
    ManufactoryTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"entityCell"];
    cell.mantitleLabel.text = m_manufact.title;
    return cell;
}

#pragma mark - UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 20;
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    [cell setBackgroundColor:[UIColor clearColor]];
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        MItemEntity *m_manufact = [[self.fetchManufactoryController sections][indexPath.section] objects][indexPath.row];
        [[FactoryDataManager defaultManager].managedObjectContext deleteObject:m_manufact];
        
        NSError *error = nil;
        [[FactoryDataManager defaultManager].managedObjectContext save:&error];
        if (!error) {
            [self applyFetch];
        } else {
            [self showErrorAlertWith:error.localizedDescription];
        }
    }
}

#pragma mark - Fetches

- (NSFetchedResultsController *)fetchManufactoryController {
    if (_fetchManufactoryController == nil) {
        NSFetchRequest *fetchRequest = [NSFetchRequest fetchRequestWithEntityName:@"ManEntity"];
        fetchRequest.sortDescriptors = @[[[NSSortDescriptor alloc] initWithKey:@"type" ascending:YES]];
        
        _fetchManufactoryController = [[NSFetchedResultsController alloc] initWithFetchRequest:fetchRequest managedObjectContext:[FactoryDataManager defaultManager].managedObjectContext sectionNameKeyPath:@"type" cacheName:@"Factory"];
        _fetchManufactoryController.delegate = (id<NSFetchedResultsControllerDelegate>)self;
    }
    
    return _fetchManufactoryController;
}

- (void)controller:(NSFetchedResultsController *)controller didChangeObject:(id)anObject atIndexPath:(nullable NSIndexPath *)indexPath forChangeType:(NSFetchedResultsChangeType)type newIndexPath:(nullable NSIndexPath *)newIndexPath {
    [self.tableView reloadData];
}

- (void)applyFetch {
    NSError *fetchError = nil;
    [self.fetchManufactoryController performFetch:&fetchError];
    
    [self.tableView reloadData];
    //! NSAssert(fetchError != nil, fetchError.localizedDescription);
}

- (void)showErrorAlertWith:(NSString *)title {
    UIAlertController *errControll = [UIAlertController alertControllerWithTitle:title message:nil preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
    
    [errControll addAction:okAction];
    [self presentViewController:errControll animated:YES completion:nil];
}

@end
