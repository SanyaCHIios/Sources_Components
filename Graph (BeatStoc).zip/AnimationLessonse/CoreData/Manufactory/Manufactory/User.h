//
//  User.h
//  Manufactory
//
//  Created by green on 25.01.17.
//  Copyright © 2017 Quad. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface User : NSObject <NSCoding>
@property (copy, nonatomic) NSString *name;
@end
