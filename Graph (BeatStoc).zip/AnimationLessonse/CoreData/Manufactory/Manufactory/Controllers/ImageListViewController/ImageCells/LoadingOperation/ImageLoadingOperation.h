
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface ImageLoadingOperation : NSOperation

@property (assign, nonatomic) BOOL isExecuting;
@property (assign, nonatomic) BOOL isCancelled;
@property (assign, nonatomic) BOOL isFinished;

+ (ImageLoadingOperation *)loadImageWithURL:(NSURL*)imageUrl queue:(NSOperationQueue *)queue progress:(void(^)(CGFloat progress))progress success:(void (^)(UIImage *loadedImage))success failure:(void (^)(NSError *error))failure;
@end
