#import "ImageTableViewCell.h"
#import "ImageLoadingOperation.h"

@interface ImageTableViewCell ()
@property (weak, nonatomic) IBOutlet UIImageView *fotoView;
@property (weak, nonatomic) IBOutlet UIProgressView *progressView;
@property (strong, nonatomic) NSOperationQueue *loadQueue;
@end

@implementation ImageTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
}

- (void)setLoadingURL:(NSURL*)imageUrl{
    self.progressView.hidden = YES;
    self.fotoView.image = nil;
    
    if (self.loadQueue.operations.count) {
        for (NSOperation *op in self.loadQueue.operations) {
            if (op.executing)
                [op cancel];
        }
    }
    __weak typeof (self) wSelf = self;
    
    ImageLoadingOperation *imLoadOp = [ImageLoadingOperation loadImageWithURL:imageUrl queue:self.loadQueue progress:^(CGFloat progress) {
        
        if (![NSThread isMainThread]) {
            dispatch_async(dispatch_get_main_queue(), ^{
                //if (wSelf.fotoView.image == nil)
                wSelf.progressView.hidden = NO;
                wSelf.progressView.progress = progress;
            });
        } else {
            if (wSelf.fotoView.image) {
                
            }
            wSelf.progressView.hidden = NO;
            wSelf.progressView.progress = progress;
        }
    } success:^(UIImage *loadedImage) {
        if ([NSThread isMainThread]) {
            wSelf.progressView.hidden = YES;
            wSelf.fotoView.image = loadedImage;
        } else {
            dispatch_async(dispatch_get_main_queue(), ^{
                wSelf.progressView.hidden = YES;
                wSelf.fotoView.image = loadedImage;
            });
        }
        if (!loadedImage) {
            NSLog(@"imaga --- > %@", wSelf.fotoView.image);
        }
    } failure:^(NSError *error) {
        //!
    }];
    
    [self.loadQueue addOperation:imLoadOp];
}

- (NSOperationQueue *)loadQueue {
    if (!_loadQueue) {
        _loadQueue = [[NSOperationQueue alloc] init];
    }
    return _loadQueue;
}

@end
