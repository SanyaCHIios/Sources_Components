#import "ImageLoadingOperation.h"

typedef void (^successBlock)(UIImage *loadedImage);
typedef void (^progressBlock)(CGFloat progress);

@interface ImageLoadingOperation () <NSURLSessionTaskDelegate>
@property (strong, nonatomic) NSURLSessionDataTask *imageTask;
@property (strong, nonatomic) NSURL *dataUrl;

@property (copy, nonatomic) successBlock success;
@property (copy, nonatomic) progressBlock progress;

@property (weak, nonatomic) NSOperationQueue *cQ;
@property (strong, nonatomic) NSURLSession *session;
@property (strong, nonatomic) NSMutableData *imageData;
@end
@implementation ImageLoadingOperation

+ (ImageLoadingOperation *)loadImageWithURL:(NSURL*)imageUrl queue:(NSOperationQueue *)queue progress:(void(^)(CGFloat progress))progress success:(void (^)(UIImage *loadedImage))success failure:(void (^)(NSError *error))failure {
    
    ImageLoadingOperation *op = [[ImageLoadingOperation alloc] initWithURL:imageUrl success:success];
    op.cQ = queue;
    op.progress = progress;
    return op;
}

- (instancetype)initWithURL:(NSURL*)imageUrl success:(successBlock)op {
    if (self = [super init]) {
        self.dataUrl = imageUrl;
        self.success = op;
        
    }
    return self;
}

- (void)main {
    
}

- (void)start {
    
    if ([self isCancelled]) {
        return;
    }
    
    NSURLSessionConfiguration *conf = [NSURLSessionConfiguration defaultSessionConfiguration];
    conf.allowsCellularAccess = NO;
    __weak typeof (self) wSelf = self;
    
    self.session = [NSURLSession sessionWithConfiguration:conf delegate:wSelf delegateQueue:self.cQ];
    
    [self willChangeValueForKey:@"isExecuting"];
    self.isExecuting = YES;
    [self didChangeValueForKey:@"isExecuting"];
    
    self.imageTask = [self.session dataTaskWithURL:self.dataUrl];
    [self.imageTask resume];
}

- (void)URLSession:(NSURLSession *)session
          dataTask:(NSURLSessionDataTask *)dataTask
    didReceiveData:(NSData *)data {
    
    if ([self isCancelled]) {
        return;
    }

    if (self.imageData == nil) {
        self.imageData = data.mutableCopy;
    } else {
        [self.imageData appendData:data];
    }
    //dataTask.response
    CGFloat prog  = (float)self.imageData.length/[dataTask.response expectedContentLength];
    if (prog >= 1) {
        
        [self willChangeValueForKey:@"isExecuting"];
        self.isExecuting = NO;
        [self didChangeValueForKey:@"isExecuting"];
        
        [self willChangeValueForKey:@"isFinished"];
        self.isFinished = YES;
        [self didChangeValueForKey:@"isFinished"];

        if (self.success) {
            if ([self isCancelled]) {
                return;
            }

            if ([NSThread isMainThread]) {
                self.success([UIImage imageWithData:self.imageData]);
            } else {
                dispatch_async(dispatch_get_main_queue(), ^{
                    self.success([UIImage imageWithData:self.imageData]);
                });
            }
        }
    } else {
        NSLog(@"downloaded %d%%", (int)(100.0*prog));
        if (self.progress) {
            self.progress(prog);
        }
    }
}

- (void)cancel {
    [super cancel];
    
    [self willChangeValueForKey:@"isExecuting"];
    self.isExecuting = NO;
    [self didChangeValueForKey:@"isExecuting"];
    
    [self willChangeValueForKey:@"isCancelled"];
    self.isCancelled = YES;
    [self didChangeValueForKey:@"isCancelled"];
    
    [self.imageTask cancel];
}

- (void)dealloc {
    
}

@end
