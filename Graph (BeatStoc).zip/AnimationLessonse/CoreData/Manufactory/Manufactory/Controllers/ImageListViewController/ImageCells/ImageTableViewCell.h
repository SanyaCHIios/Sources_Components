#import <UIKit/UIKit.h>

@interface ImageTableViewCell : UITableViewCell
- (void)setLoadingURL:(NSURL*)imageUrl;
@end
