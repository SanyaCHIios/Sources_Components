
#import "ImageListViewController.h"
#import "ImageTableViewCell.h"

#define CELL_BOUNDS_COEF 0.5
@interface ImageListViewController ()

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (assign, nonatomic) CGFloat cellHeight;
@end

@implementation ImageListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self calculationFoCellHeiht];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

#pragma mark - preparing suport data

- (void)calculationFoCellHeiht {
    self.cellHeight = CGRectGetWidth([UIScreen mainScreen].bounds) * CELL_BOUNDS_COEF;
}

#pragma mark  - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 10;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ImageTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"imageCellID"];
    
    if (indexPath.row%2 == 0) {
        //http://www.planwallpaper.com/static/images/9-credit-1.jpg
        [cell setLoadingURL:[NSURL URLWithString:@"http://www.planwallpaper.com/static/images/9-credit-1.jpg"]];
    } else if (indexPath.row%3 == 0) {
        //http://www.planwallpaper.com/static/images/orangutan_1600x1000_279157.jpg
        [cell setLoadingURL:[NSURL URLWithString:@"http://www.planwallpaper.com/static/images/orangutan_1600x1000_279157.jpg"]];
    } else {
        [cell setLoadingURL:[NSURL URLWithString:@"http://www.planwallpaper.com/static/images/canberra_hero_image_JiMVvYU.jpg"]];
    }
    
    return  cell;
}

#pragma mark  - UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return self.cellHeight;
}
@end
