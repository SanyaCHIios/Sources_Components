//
//  ManufactoryTableViewCell.h
//  Manufactory
//
//  Created by green on 17.02.17.
//  Copyright © 2017 Quad. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ManufactoryTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *mantitleLabel;

@end
