
#import <UIKit/UIKit.h>

@interface MButton : UIButton
@property (strong, nonatomic) IBInspectable UIColor *hightlitedColor;
@property (strong, nonatomic) IBInspectable UIColor *defaultColor;
@property (strong, nonatomic) IBInspectable UIColor *selectedColor;
@end
