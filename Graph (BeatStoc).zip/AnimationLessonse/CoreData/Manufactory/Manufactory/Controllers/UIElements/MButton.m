#import "MButton.h"

@implementation MButton

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

#pragma mark - Custome behavior

- (void)awakeFromNib {
    [super awakeFromNib];
    self.layer.cornerRadius = 5;
}

- (void)setHighlighted:(BOOL)highlighted {
    [super setHighlighted:highlighted];
    
    if (CGColorEqualToColor(self.backgroundColor.CGColor, [UIColor clearColor].CGColor)) {
        return;
    }
    
    if (highlighted) {
        if (self.isSelected) {
            
        }else {
            self.backgroundColor = self.hightlitedColor;
        }

    } else {
        if (self.isSelected) {
            
        }else {
            self.backgroundColor = self.defaultColor;
        }
    }
}

@end
