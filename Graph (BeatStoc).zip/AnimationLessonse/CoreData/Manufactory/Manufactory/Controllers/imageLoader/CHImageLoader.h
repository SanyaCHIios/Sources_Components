#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface CHImageLoader : NSObject

+ (UIImage *)loadImageFromURL:(NSURL *)imageUrl;

@end
