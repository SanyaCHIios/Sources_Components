import UIKit
import AVKit

// swiftlint:disable force_unwrapping

class SlideView: UIView {
    var addedTouchArea = CGFloat(50)

    override func point(inside point: CGPoint, with event: UIEvent?) -> Bool {

        let newBound = CGRect(
            x: self.bounds.origin.x - addedTouchArea,
            y: self.bounds.origin.y - addedTouchArea,
            width: self.bounds.width + 2 * addedTouchArea,
            height: self.bounds.height + 2 * addedTouchArea
        )
        return newBound.contains(point)
    }
}

class VideoViewController: UIViewController {

    let videoPlayer = AVPlayerViewController()
    var videoURL: URL?

    var fullScreenView: DACVideoFullScreenView = Bundle.main.loadNibNamed("DACVideoFullScreenView", owner: self, options: nil)!.first as! DACVideoFullScreenView
    
    @IBOutlet weak var expandButton: UIButton!
    @IBOutlet weak var pipButton: UIButton!
    @IBOutlet weak var volumeButton: UIButton!

    @IBOutlet weak var controlsView: UIView!

    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var playshowComponentsButton: UIButton!
    @IBOutlet weak var currentTimeLabel: UILabel!
    @IBOutlet weak var timeLeftLabel: UILabel!
    @IBOutlet weak var trachView: SlideView!

    @IBOutlet weak var timelineDotView: SlideView!
    var timelineView = UIView(frame: CGRect.zero)

    var isFirsLoad = true

    @IBOutlet weak var playerHolder: UIView!


    @IBOutlet weak var pipModeView: UIView!
    @IBOutlet weak var stateImage: UIImageView!
    var seekWidth: CGFloat = 0.0

    deinit {
        print("deinit -> VideoViewController!!!")
        NotificationCenter.default.removeObserver(self)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        preparePlayerControls()

        NotificationCenter.default.addObserver(self, selector: #selector(rotated), name: UIDevice.orientationDidChangeNotification, object: nil)

        let gesture = UIPanGestureRecognizer(target: self, action: #selector(seekAction))
        timelineDotView.addGestureRecognizer(gesture)
    }

    @objc func seekAction(gest:UIPanGestureRecognizer) {
        if gest.state == .began {
            seekWidth = timelineDotView.center.x
        }
        if gest.state == .began || gest.state == .changed {
            let translation = gest.translation(in: self.trachView)

            var nextX = seekWidth + translation.x
            if nextX < 0 {
                nextX = 0
            }
            if nextX >= trachView.bounds.width {
                nextX = trachView.bounds.width
                PlayerManager.main.palyarStatus = .ended
            } else if PlayerManager.main.palyarStatus == .ended {
                PlayerManager.main.palyarStatus = .paused
            }

            seekWidth = nextX
            timelineDotView.center.x = nextX
            let currentPosition = Double(seekWidth) / (Double(trachView.frame.width) / PlayerManager.main.trackDuration())

            if let player = PlayerManager.main.player {
                player.seek(to: CMTime(seconds: currentPosition, preferredTimescale: 10), toleranceBefore: .zero, toleranceAfter: .zero)
            }
  
            gest.setTranslation(CGPoint(x: 0, y: 0), in: self.view)
        }
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

//        let playerItem = AVPlayerItem(url: videoURL!)
//        let player = AVPlayer(playerItem: playerItem)
//        videoPlayer.player = player
//        addChild(videoPlayer)
//        videoPlayer.view.frame = CGRect(x: 0, y: 0, width: playerHolder.frame.width, height: playerHolder.frame.height)
//        playerHolder.addSubview(videoPlayer.view)
//        videoPlayer.didMove(toParent: self)

        PlayerManager.main.prepareVideoplayer(url: videoURL!)
        if let playerLayer = PlayerManager.main.playerLayer {
            prepareCallBacks()
            playerLayer.frame = CGRect(x: 0, y: 0, width: playerHolder.frame.width, height: playerHolder.frame.height)
            playerLayer.backgroundColor = UIColor.black.cgColor
            playerHolder.layer.insertSublayer(playerLayer, at: 0)
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
    }

    //! MARK: Rotation

    @objc func rotated() {
        if PlayerManager.main.isConfigured && PlayerManager.main.pipController.status != .showed {
            if fullScreenView.superview == nil {
                guard let playerLayer = PlayerManager.main.playerLayer else {
                 return
                }
                playerLayer.frame = CGRect(x: 0, y: 0, width: playerHolder.frame.width, height: playerHolder.frame.height)
                updateTimeLine()
            }
        } else if PlayerManager.main.pipController.status == .showed {
            PlayerManager.main.updatePipPosition()
        }
    }

    //! MARK: Actions

    @IBAction func startPIP(_ sender: Any) {
        if PlayerManager.main.isConfigured {
            //! hide all controls
            hideControls()
            //! disable interaction
            playshowComponentsButton.isEnabled = false
            //! show plaseholder for player
            pipModeView.isHidden = false
            //! stat pip
            PlayerManager.main.pipController.startPIP()
        }
    }

    //! play button also configured sowing and hid for controls
    //! selected - controls showed and wice wersa
    @IBAction func playAction(_ sender: UIButton) {
        if PlayerManager.main.isConfigured {

            if isFirsLoad {
                playContentAction(sender)
                isFirsLoad = false
            }

            sender.setImage(nil, for: .normal)
            sender.isSelected = !sender.isSelected

            if sender.isSelected {
                showControls()
            } else {
                hideControls(animaton: true)
            }
        }
    }

    @IBAction func playContentAction(_ sender: UIButton) {
        if PlayerManager.main.playerStaus() != PlayerManager.DacPlayerStatus.played {
            PlayerManager.main.play()
        } else {
            PlayerManager.main.pause()
        }
        updateIcons()
    }

    @IBAction func fullScreenAction(_ sender: UIButton) {
        showFullscreen()
    }

    //! MARK: main controlls hide/show

    func preparePlayerControls() {
        hideControls(animaton: true)
        stateImage.image = UIImage(named: "pipLargeIcon")!.withRenderingMode(.alwaysTemplate)
    }

    func showControls() {
        UIView.animate(withDuration: 0.3) {
            self.expandButton.alpha = 1.0
            self.pipButton.alpha = 1.0
            self.volumeButton.alpha = 1.0
            self.controlsView.alpha = 1.0
        }
    }

    func hideControls() {
        self.expandButton.alpha = 0.0
        self.pipButton.alpha = 0.0
        self.volumeButton.alpha = 0.0
        self.controlsView.alpha = 0.0

        if playshowComponentsButton.isSelected {
            playshowComponentsButton.isSelected = false
        }
    }

    func hideControls(animaton:Bool) {
        if animaton {
            UIView.animate(withDuration: 0.3) {
                self.hideControls()
            }
        } else {
            hideControls()
        }
    }

    //! MARK: Show fullscreenmode

    func showFullscreen() {
        let application = UIApplication.shared
        if let window = application.windows.first {
            let fullscreenTag = 10000
            fullScreenView.frame = UIScreen.main.bounds
            fullScreenView.tag = fullscreenTag
            fullScreenView.addLayer()
            window.addSubview(fullScreenView)

            fullScreenView.didEndFullMode = {
                if let fullView = window.viewWithTag(fullscreenTag) {
                    fullView.removeFromSuperview()
                    self.updateTimeLine()
                    self.prepareCallBacks()
                    self.addVideoLayer()
                    self.updateIcons()
                }
            }

            fullScreenView.didStatrPipMode = {
                if let fullView = window.viewWithTag(fullscreenTag) {
                    fullView.removeFromSuperview()
                    PlayerManager.main.pipController.presentationMode = .full
                    self.startPIP(self.playshowComponentsButton)
                }
            }
        }
    }

    //! MARK: Video layer

    func addVideoLayer() {
        guard let playerLayer = PlayerManager.main.playerLayer else {
            return
        }

        CATransaction.begin()
        CATransaction.setAnimationDuration(0)
        CATransaction.setDisableActions(true)
        playerLayer.frame = CGRect(x: 0, y: 0, width: playerHolder.frame.width, height: playerHolder.frame.height)
        CATransaction.commit()

        playerLayer.backgroundColor = UIColor.black.cgColor
        playerHolder.layer.insertSublayer(playerLayer, at: 0)
        updateIcons()
    }

    //! MARK: Updating time and progres views

    func updateTimeLine() {
        if PlayerManager.main.trackDuration() > 0 {
            let currentPosition = (Double(trachView.frame.width) / PlayerManager.main.trackDuration())*PlayerManager.main.currentSecconds
            if timelineView.superview == nil {
                trachView.insertSubview(timelineView, at: 0)
                timelineView.layer.cornerRadius = 2.5
                timelineView.backgroundColor = #colorLiteral(red: 0.7162558417, green: 0.7162558417, blue: 0.7162558417, alpha: 1)
                controlsView.addControlsBlurEffect()
            }
            timelineView.frame = CGRect(x: 0, y: 0, width: CGFloat(currentPosition), height: trachView.frame.height)
            timelineDotView.center = CGPoint(x: CGFloat(currentPosition), y: timelineDotView.center.y)

            currentTimeLabel.text = VideoViewController.stringForDuration(duration: Int(round(PlayerManager.main.currentSecconds)), prefix: nil)
            timeLeftLabel.text = VideoViewController.stringForDuration(duration: Int(round(PlayerManager.main.trackDuration() - PlayerManager.main.currentSecconds)), prefix: "-")
        }
    }

    func updateIcons() {
        if PlayerManager.main.playerStaus() == PlayerManager.DacPlayerStatus.played {
            playButton.setImage(UIImage(named: "pauseIcon"), for: .normal)
        } else {
            playButton.setImage(UIImage(named: "playIcon"), for: .normal)
        }
    }

    func prepareCallBacks() {
        PlayerManager.main.pipController.didEndClosure = {[weak self] in

            if PlayerManager.main.pipController.presentationMode == .full {
                PlayerManager.main.pipController.presentationMode = .normal
                self?.showFullscreen()
                self?.pipModeView.isHidden = true
                self?.playshowComponentsButton.isEnabled = true
            } else {
                self?.pipModeView.isHidden = true
                self?.addVideoLayer()
                self?.playshowComponentsButton.isEnabled = true
            }
        }
        PlayerManager.main.changeState = {[weak self] state in
            self?.updateIcons()
        }

        PlayerManager.main.timeChangeClosure = { [weak self] in
            self?.updateTimeLine()
        }
    }
}

//! MARK: Formatting time

extension VideoViewController {
    class func stringForDuration(duration: Int, prefix: String?) -> String {
        let hours = Int(duration / 3600)
        let min = Int((duration / 60) % 60)
        let sec = Int(duration % 60)

        var strH = hours >= 10 ? "\(hours)" : "0\(hours)"

        if hours == 0 {
            strH = ""
        }

        let strM = min >= 10 ? "\(min)" : "0\(min)"
        let strS = sec >= 10 ? "\(sec)" : "0\(sec)"

        var formatted = ""
        if let prf = prefix {
            formatted += prf
        }
        if strH.isEmpty {
            return formatted + strM + ":" + strS
        }
        return formatted + strH + ":" + strM + ":" + strS
    }
}

// swiftlint:enable force_unwrapping
