import UIKit
import AVKit

class DACVideoFullScreenView: UIView {

    var didEndFullMode: (() -> Void)?
    var didStatrPipMode: (() -> Void)?
    
    @IBOutlet weak var videoLayerHolder: UIView!

    @IBOutlet weak var playPauseButton: UIButton!
    @IBOutlet weak var playerControllView: UIView!
    @IBOutlet weak var currentTimeLabel: UILabel!
    @IBOutlet weak var leftTimeLabel: UILabel!
    @IBOutlet weak var timeTrackView: SlideView!
    @IBOutlet weak var seekView: SlideView!
    var seekWidth: CGFloat = 0.0

    var timelineView = UIView(frame: CGRect.zero)

    deinit {
        print("deinit > DACFullScreenView")
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        playerControllView.addControlsBlurEffect()

        let gesture = UIPanGestureRecognizer(target: self, action: #selector(seekAction))
        seekView.addGestureRecognizer(gesture)
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        guard let playerLayer = PlayerManager.main.playerLayer else {
            return
        }
        if playerLayer.frame.width != videoLayerHolder.frame.width {
            playerLayer.frame = CGRect(x: 0, y: 0, width: videoLayerHolder.frame.width, height: videoLayerHolder.frame.height)
            updateTimeLine()
        }
    }

    //! MARK: Actions

    @IBAction func closeFullModeAction(_ sender: Any) {
        if let end = didEndFullMode {
            end()
        }
    }

    @IBAction func playPauseButton(_ sender: Any) {
        if PlayerManager.main.playerStaus() != PlayerManager.DacPlayerStatus.played {
            PlayerManager.main.play()
        } else {
            PlayerManager.main.pause()
        }
        updateIcons()
    }

    @IBAction func starpPIPMode(_ sender: Any) {
        if let startPip = didStatrPipMode {
            startPip()
        }
    }

    //! MARk: Helper

    func addLayer() {
        guard let playerLayer = PlayerManager.main.playerLayer else {
            return
        }
        playerLayer.removeFromSuperlayer()
        playerLayer.frame = CGRect(x: 0, y: 0, width: videoLayerHolder.frame.width, height: videoLayerHolder.frame.height)
        videoLayerHolder.layer.insertSublayer(playerLayer, at: 0)
        prepareForPlaying()
        updateTimeLine()
    }

    @objc func seekAction(gest:UIPanGestureRecognizer) {
        if gest.state == .began {
            seekWidth = seekView.center.x
        }

        if gest.state == .began || gest.state == .changed {
            let translation = gest.translation(in: timeTrackView)
            print("seek to time tetet -> \(translation)")
            var nextX = seekWidth + translation.x
            if nextX < 0 {
                nextX = 0
            }
            if nextX >= timeTrackView.bounds.width {
                nextX = timeTrackView.bounds.width
                PlayerManager.main.palyarStatus = .ended
            } else if PlayerManager.main.palyarStatus == .ended {
                PlayerManager.main.palyarStatus = .paused
            }
            
            seekWidth = nextX
            seekView.center.x = nextX
            let currentPosition = Double(seekWidth) / (Double(timeTrackView.frame.width) / PlayerManager.main.trackDuration())
            print("seek to time -> \(currentPosition) pp: \(seekWidth)")
            if let player = PlayerManager.main.player {
                player.seek(to: CMTime(seconds: currentPosition, preferredTimescale: 10), toleranceBefore: .zero, toleranceAfter: .zero)
            }
            gest.setTranslation(CGPoint(x: 0, y: 0), in: timeTrackView)
        }
    }

    func prepareForPlaying() {
        PlayerManager.main.changeState = {[weak self] state in
            self?.updateIcons()
        }
        PlayerManager.main.timeChangeClosure = {[weak self] in
            self?.updateTimeLine()
        }
        updateIcons()
    }

    #warning("need refactoring!!!!")
    func updateIcons() {
        if PlayerManager.main.playerStaus() == PlayerManager.DacPlayerStatus.played {
            playPauseButton.setImage(UIImage(named: "pauseFullIcon"), for: .normal)
        } else {
            playPauseButton.setImage(UIImage(named: "playFuulScrrenIcon"), for: .normal)
        }
    }

    func updateTimeLine() {
        if PlayerManager.main.trackDuration() > 0 {
            let currentPosition = (Double(timeTrackView.frame.width) / PlayerManager.main.trackDuration())*PlayerManager.main.currentSecconds
            print("(updateTimeLine) current position - \(PlayerManager.main.currentSecconds) pp: - \(currentPosition)")
            if timelineView.superview == nil {
                timeTrackView.insertSubview(timelineView, at: 0)
                timelineView.layer.cornerRadius = 2.5
                timelineView.backgroundColor = #colorLiteral(red: 0.7162558417, green: 0.7162558417, blue: 0.7162558417, alpha: 1)
            }
            timelineView.frame = CGRect(x: 0, y: 0, width: CGFloat(currentPosition), height: timeTrackView.frame.height)
            seekView.center = CGPoint(x: CGFloat(currentPosition), y: seekView.center.y)

            currentTimeLabel.text = VideoViewController.stringForDuration(duration: Int(round(PlayerManager.main.currentSecconds)), prefix: nil)
            leftTimeLabel.text = VideoViewController.stringForDuration(duration: Int(round(PlayerManager.main.trackDuration() - PlayerManager.main.currentSecconds)), prefix: "-")
        }
    }
}

extension UIView {
    func addControlsBlurEffect() {
        let blurEffect = UIBlurEffect(style: UIBlurEffect.Style.dark)
        let blurEffectView = UIVisualEffectView(effect: blurEffect)
        blurEffectView.frame = bounds
        blurEffectView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        insertSubview(blurEffectView, at: 0)
    }
}
