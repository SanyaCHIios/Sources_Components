//
//  DACPIPViewController.swift
//  Rocket.Chat
//
//  Created by Alex iOS on 9/17/19.
//  Copyright © 2019 Rocket.Chat. All rights reserved.
//

import UIKit
import AVKit

class DACPIPViewController: UIView {

    enum PipMenuStatus {
        case needShow, showed, canceled
    }

    enum PipStatus {
        case none, showed
    }

    enum PipPresentMode {
        case normal, full
    }

    enum PipPosition {
        case leftTop, rightTop, leftBottom, rightBottom
    }

    var status = PipStatus.none
    var pipMenuStatus = PipMenuStatus.canceled
    var pipPosition = PipPosition.rightBottom
    var presentationMode = PipPresentMode.normal

    let maxRes:CGFloat = 190
    var pipSize = CGSize(width: 190, height: 190)

    let bottomMenuHeight: CGFloat = 50
    let animationDuration: CGFloat = 0.3

    var pipCurrentFrame: CGRect?
    var playButton: UIButton?
    var pinchGesture: UIPinchGestureRecognizer?
    var afterTask: DispatchWorkItem?
    var previousPosition = CGPoint.zero

    var didEndClosure: (() -> Void)?

    //! keyboard
    var keyboardShowed = false

    deinit {

    }

    open func startPIP() {
        let gener = AVAssetImageGenerator(asset: PlayerManager.main.player!.currentItem!.asset)
//        do {
//            let imge = try gener.copyCGImage(at: CMTime.zero, actualTime: nil)
//            if imge.width > imge.height {
//                let coef = CGFloat(imge.height)/CGFloat(imge.width)
//                pipSize = CGSize(width: maxRes, height: maxRes*coef)
//            } else {
//                let coef = CGFloat(imge.width)/CGFloat(imge.height)
//                pipSize = CGSize(width: maxRes*coef, height: maxRes)
//            }
//        } catch _ {}

        frame = CGRect(x: 0, y: 0, width: pipSize.width, height: pipSize.height)

        if pinchGesture == nil {
            pinchGesture = UIPinchGestureRecognizer(target: self, action: #selector(pinchAction))
            addGestureRecognizer(pinchGesture!)
        }

        PlayerManager.main.changeState = { state in
            if self.status == .showed, let button = self.playButton {
                if state != .played {
                    button.setImage(UIImage(named: "playIcon"), for: .normal)
                } else {
                    button.setImage(UIImage(named: "pauseIcon"), for: .normal)
                }
            }
        }

        center = rightBottomStartPosition()

        guard let pLayer = PlayerManager.main.playerLayer else {
            return
        }

        pipCurrentFrame = frame

        pLayer.removeFromSuperlayer()
        pLayer.frame = CGRect(x: 0, y: 0, width: pipSize.width, height: pipSize.height)
        layer.addSublayer(pLayer)

        let application = UIApplication.shared
        if let window = application.windows.first {
            tag = 1000
            window.addSubview(self)
            status = .showed

            NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(_:)),
                                                   name: UIResponder.keyboardWillShowNotification,
                                                   object: nil)
            NotificationCenter.default.addObserver(self,
                                                   selector: #selector(keyboardWillHide(_:)),
                                                   name: UIResponder.keyboardWillHideNotification,
                                                   object: nil)
        }
    }

    //! MARK: keyboard

    @objc func keyboardWillShow(notification: Notification) {
        keyboardShowed = true
        if keyboardShowed {
            switch pipPosition {
            case .leftBottom:
                 var correcPossition = leftUpStartPosition()

                   UIView.animate(withDuration: TimeInterval(animationDuration*coef), animations: {
                       self.center = correcPossition
                   }, completion: { (finished) in
                   })
            default:
                print("keyboardWillShow")
            }
        }
    }

    @objc func keyboardWillHide(notification: Notification) {
        keyboardShowed = false
        switch pipPosition {
        case .leftBottom:
             var correcPossition = leftBottomStartPosition()

               UIView.animate(withDuration: TimeInterval(animationDuration*coef), animations: {
                   self.center = correcPossition
               }, completion: { (finished) in
               })
        default:
            print("keyboardWillShow")
        }
    }
}

extension DACPIPViewController {

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        guard let touch: UITouch = touches.first else {
            return
        }
        previousPosition = touch.location(in: self.superview)

        if pipMenuStatus == .canceled, touch.tapCount == 1 {
            pipMenuStatus = .needShow
        }
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesMoved(touches, with: event)
        guard let touch: UITouch = touches.first else {
            return
        }

        if touch.tapCount > 1 {
            return
        }

        let position = touch.location(in: superview)
        center = CGPoint(x: center.x + (position.x - previousPosition.x), y: center.y + (position.y - previousPosition.y))
        previousPosition = position
        pipMenuStatus = .canceled
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesEnded(touches, with: event)

        guard let touch: UITouch = touches.first else {
            return
        }
        if touch.tapCount > 1 {
            return
        }
        let position = touch.location(in: superview)
        setCurrentPosition(position: position)
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesCancelled(touches, with: event)
    }

    func setCurrentPosition(position: CGPoint) {
        if let supView = superview {

            let maxDistance = sqrt(pow(supView.frame.size.height, 2) + pow(supView.frame.size.width, 2))/2

            var leftDist = abs(supView.frame.size.width/2 - (supView.frame.size.width - position.x))
            var bottomDist = abs(supView.frame.size.height - position.y)

            if position.y < supView.frame.size.height/2 {
                bottomDist = abs(supView.frame.size.height/2 - (supView.frame.size.height/2 - position.y))
            }
            if position.x < supView.frame.size.width/2 {
                leftDist = abs(supView.frame.size.width/2 - (supView.frame.size.width/2 - position.x))
            }
            let currentDistance = sqrt(pow(bottomDist, 2) + pow(leftDist, 2))
            var coef = currentDistance/maxDistance

            //! restriction for minimal(0.3) coeficient
            if coef < 0.3 {
                coef = 0.3
            }

            var correcPossition = CGPoint.zero
            if position.x < supView.frame.size.width/2 && position.y < supView.frame.size.height/2 {
                correcPossition = leftUpStartPosition()
                pipPosition = PipPosition.leftTop
            } else if position.x >= supView.frame.size.width/2 && position.y < supView.frame.size.height/2 {
                correcPossition = rightUpStartPosition()
                pipPosition = PipPosition.rightTop
            } else if position.x < supView.frame.size.width/2 && position.y >= supView.frame.size.height/2 {
                correcPossition = leftBottomStartPosition()
                pipPosition = PipPosition.leftBottom
            } else {
                correcPossition = rightBottomStartPosition()
                pipPosition = PipPosition.rightBottom
            }

            UIView.animate(withDuration: TimeInterval(animationDuration*coef), animations: {
                self.center = correcPossition
            }, completion: { (finished) in
                if finished {
                    self.showMenuIfNeeded()
                }
            })
        }
    }

    //! MARK: default positions

    func leftUpStartPosition() -> CGPoint {
        return CGPoint(x: 25+frame.size.width/2, y: 70+frame.size.height/2)
    }

    func rightUpStartPosition() -> CGPoint {
        let xPosition = UIScreen.main.bounds.width - (frame.size.width/2+25)
        return CGPoint(x: xPosition, y: 70+frame.size.height/2)
    }

    func rightBottomStartPosition() -> CGPoint {
        let xPosition = UIScreen.main.bounds.width - (frame.size.width/2+25)
        let yPosition = UIScreen.main.bounds.height - (frame.size.height/2+50)
        return CGPoint(x: xPosition, y: yPosition)
    }

    func leftBottomStartPosition() -> CGPoint {
        let yPosition = UIScreen.main.bounds.height - (frame.size.height/2+50)
        return CGPoint(x: 25+frame.size.width/2, y: yPosition)
    }

    //! menu present

    func showMenuIfNeeded() {
        if pipMenuStatus == .needShow {
            let mainView = UIView(frame: CGRect(x: 0, y: bounds.height - bottomMenuHeight, width: bounds.width, height: bottomMenuHeight))
            mainView.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.0)
            mainView.tag = 1003
            self.addSubview(mainView)

            let buttonsWH: CGFloat = 40
            let space: CGFloat = 10
            let elementsWidth = buttonsWH*3+space*2
            let grap = (bounds.width-elementsWidth)/2

            //! minimaze button
            addButton(mainview: mainView, image: UIImage(named: "backFromPipIcon"), xPosition: grap, buttonsWH: buttonsWH, selector: #selector(backToNormalVideoFrame))

            //! play button
            playButton = addButton(mainview: mainView, image: UIImage(named: PlayerManager.main.isPlaying() ? "pauseIcon" : "playIcon"), xPosition: grap+buttonsWH+space, buttonsWH: buttonsWH, selector: #selector(playVideoInPIP))

            //! close button
           addButton(mainview: mainView, image: UIImage(named: "closeIcon"), xPosition: grap+buttonsWH*2+space*2, buttonsWH: buttonsWH, selector: #selector(closePIPView))

            pipMenuStatus = .showed
            afterTask = DispatchWorkItem {
                if let view = self.viewWithTag(1003) {
                    self.afterTask = nil
                    view.removeFromSuperview()
                    self.pipMenuStatus = .canceled
                }
            }

            if let after = afterTask {
                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 3, execute: after)
            }

        } else if pipMenuStatus == .showed {
            if let after = afterTask {
                after.cancel()
                afterTask = nil
            }

            if let view = self.viewWithTag(1003) {
                view.removeFromSuperview()
                self.pipMenuStatus = .canceled
            }
        }
    }

    @discardableResult
    func addButton(mainview: UIView, image :UIImage?, xPosition:CGFloat, buttonsWH: CGFloat, selector:Selector) -> UIButton {
        
        let closeButton = UIButton(type: .custom)
        closeButton.frame = CGRect(x: xPosition, y: 5, width: buttonsWH, height: buttonsWH)
        closeButton.setImage(image, for: .normal)
        closeButton.addTarget(self, action: selector, for: .touchUpInside)
        closeButton.layer.cornerRadius = buttonsWH/2
        closeButton.backgroundColor = UIColor(red: 0.9, green: 0.9, blue: 0.9, alpha: 0.6)
        closeButton.clipsToBounds = true
        mainview.addSubview(closeButton)
        return closeButton
    }

    //! MARK: Actions

    @objc func pinchAction(_ gestureRecognizer : UIPinchGestureRecognizer) {
        guard gestureRecognizer.view != nil else { return }

        if gestureRecognizer.state == .began {
            print("pipMenuStatus -> \(pipMenuStatus)")

            if let view = viewWithTag(1003) {
                if let after = afterTask {
                    after.cancel()
                    afterTask = nil
                }
                view.removeFromSuperview()
                pipMenuStatus = .canceled
            }

        } else if gestureRecognizer.state == .changed {
            print("scale -> \(gestureRecognizer.scale)")
            if frame.width*gestureRecognizer.scale > (UIScreen.main.bounds.width-48) || frame.height*gestureRecognizer.scale > (UIScreen.main.bounds.height-48) {
                return
            }

            if frame.width*gestureRecognizer.scale <= pipSize.width || frame.height*gestureRecognizer.scale <= pipSize.height {
                return
            }

            switch pipPosition {
            case .leftTop:
                gestureRecognizer.view?.frame = CGRect(x: frame.minX, y: frame.minY, width: frame.width*gestureRecognizer.scale, height: frame.height*gestureRecognizer.scale)
            case .rightBottom:
                let nextH = frame.height - frame.height*gestureRecognizer.scale
                let nextW = frame.width - frame.width*gestureRecognizer.scale
                gestureRecognizer.view?.frame = CGRect(x: frame.minX+nextW, y: frame.minY+nextH, width: frame.width*gestureRecognizer.scale, height: frame.height*gestureRecognizer.scale)
            case .leftBottom:
                let nextH = frame.height - frame.height*gestureRecognizer.scale
                gestureRecognizer.view?.frame = CGRect(x:frame.minX, y: frame.minY+nextH, width: frame.width*gestureRecognizer.scale, height: frame.height*gestureRecognizer.scale)
            default:
                let nextW = frame.width - frame.width*gestureRecognizer.scale
                gestureRecognizer.view?.frame = CGRect(x:frame.minX+nextW, y: frame.minY, width: frame.width*gestureRecognizer.scale, height: frame.height*gestureRecognizer.scale)
            }
            gestureRecognizer.scale = 1.0

            guard let pLayer = PlayerManager.main.playerLayer else {
                return
            }
            CATransaction.begin()
            CATransaction.setAnimationDuration(0)
            CATransaction.setDisableActions(true)
            pLayer.frame = CGRect(x: 0, y: 0, width: bounds.width, height: bounds.height)
            CATransaction.commit()

        } else if gestureRecognizer.state == .ended {
            setCurrentPosition(position: center)
        }
    }


    @objc func backToNormalVideoFrame() {
        let application = UIApplication.shared
        if let window = application.windows.first {
            if let view = window.viewWithTag(1000), view is DACPIPViewController {
                view.removeFromSuperview()
                pipMenuStatus = .canceled
                PlayerManager.main.playerLayer?.removeFromSuperlayer()
                status = .none

                if let end = self.didEndClosure {
                    end()
                }
            }
        }

    }

    @objc func playVideoInPIP() {
        if let plaerObj = PlayerManager.main.player {
            if PlayerManager.main.palyarStatus == .ended {
                plaerObj.seek(to: CMTime.zero)
            }
            plaerObj.play()
            PlayerManager.main.palyarStatus = .played
        }
    }

    @objc func closePIPView() {
        let application = UIApplication.shared
        if let window = application.windows.first {
            if let view = window.viewWithTag(1000), view is DACPIPViewController {
                view.removeFromSuperview()
                pipMenuStatus = .canceled
                PlayerManager.main.playerLayer?.removeFromSuperlayer()
                status = .none

                if let end = self.didEndClosure {
                    end()
                } else {
                    PlayerManager.main.resetPlayer()
                }
            }
        }
    }
}

class PlayerManager {
    static let main = PlayerManager()
    var pipController = DACPIPViewController()

    var playerLayer: AVPlayerLayer?
    var player: AVPlayer?
    var timeChangeClosure: (() -> Void)?

    var timeObserver: Any?
    var currentSecconds: Double = 0.0
    var isConfigured = false

    //!
    enum DacPlayerStatus {
        case paused, played, ended
    }
    var palyarStatus: DacPlayerStatus = DacPlayerStatus.ended {
        didSet {
            if let changeState = self.changeState {
                changeState(palyarStatus)
            }
        }
    }
    var changeState: ((_ status: DacPlayerStatus) -> Void)?

    func resetPlayer() {
        if let observer = timeObserver {
            player?.removeTimeObserver(observer)
        }
        player = nil
        playerLayer = nil
        changeState = nil
    }

    open func prepareVideoplayer(url: URL?) {

        let playerItem = AVPlayerItem(url: url!)
//        _ = playerItem.observe(\.status, changeHandler: { [weak self] (item, value) in
//            switch item.status {
//            case .unknown:
//                debugPrint("status: unknown")
//            case .readyToPlay:
//                debugPrint("status: ready to play")
//            case .failed:
//                debugPrint("playback failed")
//            }
//        })

        self.player = AVPlayer(playerItem: playerItem)
        self.playerLayer = AVPlayerLayer(player: player)
        self.playerLayer?.removeAllAnimations()

        if let pPlayer = self.player {
            timeObserver = pPlayer.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.2, preferredTimescale: 1000000000), queue: DispatchQueue.main) { (time) in
                print("time = \(time.seconds) end time = \(pPlayer.currentItem?.duration.seconds ?? 0) scale = \(time.timescale)")
                self.currentSecconds = time.seconds
                if let end = self.timeChangeClosure {
                    end()
                }
                if time.seconds == (pPlayer.currentItem?.duration.seconds ?? 0) {
                    self.palyarStatus = .ended
                }
            }
            isConfigured = true
        }
    }

    func isPlaying() -> Bool {
        return player?.timeControlStatus == AVPlayer.TimeControlStatus.playing
    }

    func play() {
        guard let pPlayer = player else {
            return
        }
        if palyarStatus == .ended {
            pPlayer.seek(to: CMTime.zero)
        }
        pPlayer.play()
        palyarStatus = .played
    }

    func trackDuration() -> Double {
        guard let pPlayer = player else {
            return 0.0
        }
        return pPlayer.currentItem?.duration.seconds ?? 0.0
    }

    func pause() {
        guard let pPlayer = player else {
            return
        }
        pPlayer.pause()
        palyarStatus = .paused
    }

    func playerStaus() -> PlayerManager.DacPlayerStatus {
        return palyarStatus
    }

    func updatePipPosition() {
        switch pipController.pipPosition {
        case .leftTop:
            pipController.center = pipController.leftUpStartPosition()
        case .rightTop:
            pipController.center = pipController.rightUpStartPosition()
        case .leftBottom:
            pipController.center = pipController.leftBottomStartPosition()
        case .rightBottom:
            pipController.center = pipController.rightBottomStartPosition()
        }
    }
}
