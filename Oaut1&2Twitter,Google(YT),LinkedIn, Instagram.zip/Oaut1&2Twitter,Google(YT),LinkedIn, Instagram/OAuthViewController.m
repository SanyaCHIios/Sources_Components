
#import "OAuthViewController.h"
#import "SignatureParam.h"
#include "hmac.h"
#include "Base64Transcoder.h"
#import  "OauthRequestManager.h"

#import "Accounts/ACAccount.h"
#import "Accounts/ACAccountCredential.h"
#import <Accounts/ACAccountStore.h>
#import <Accounts/ACAccountType.h>

@interface OAuthViewController () <UIWebViewDelegate>

@property (strong, nonatomic) NSString *nonce;
@property (strong, nonatomic) NSString *time;

@property (strong, nonatomic) UIWebView *webView;

@property (strong, nonatomic) NSString *authT;
@property (strong, nonatomic) NSString *authVerif;

@property (strong, nonatomic) UIActivityIndicatorView *activitiIndecator;

@property (strong, nonatomic) NSString * socialRequestTokenURL;
@property (strong, nonatomic) NSString * socialAuthorizeTokenURL;
@property (strong, nonatomic) NSString * socialAccessTokenURL;

@property (strong, nonatomic) NSString * key;
@property (strong, nonatomic) NSString * secret;
@property (strong, nonatomic) NSString * redirect;
@property (assign, nonatomic) SocialType type;

@property (assign, nonatomic) BOOL isOAUTH2;

@end

@implementation OAuthViewController

- (instancetype)initWithRequestOautTokenURL:(NSString *)requestTURL
                                   authTURL:(NSString *)authTURL
                                 accessTURL:(NSString *)accessTURL
                                        key:(NSString *)key
                                     secret:(NSString *)secret
                                   redirect:(NSString *)redirect
                                       type:(SocialType)type{
    if (self = [super init]) {
        self.socialRequestTokenURL = requestTURL;
        self.socialAuthorizeTokenURL = authTURL;
        self.socialAccessTokenURL = accessTURL;
        
        self.key = key;
        self.secret = secret;
        
        self.redirect = redirect;
        self.type = type;
        
        self.isOAUTH2 = NO;
        [self addUIComponents];
    }
    
    return self;
}

- (instancetype)initWithRequestOaut2authTURL:(NSString *)authTURL
                                  accessTURL:(NSString *)accessTURL
                                         key:(NSString *)key
                                      secret:(NSString *)secret
                                    redirect:(NSString *)redirect
                                        type:(SocialType)type {
    
    if (self = [super init]) {
        self.socialAuthorizeTokenURL = authTURL;
        self.socialAccessTokenURL = accessTURL;
        
        self.key = key;
        self.secret = secret;
        
        self.redirect = redirect;
        self.type = type;
        
        self.isOAUTH2 = YES;
        [self addUIComponents];
    }
    
    return self;
}

- (void)addUIComponents {
    self.webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth([UIScreen mainScreen].bounds), CGRectGetHeight([UIScreen mainScreen].bounds))];
    [self.view addSubview:self.webView];
    
    self.activitiIndecator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    self.activitiIndecator.center =self.webView.center;
    
    [self.webView addSubview:self.activitiIndecator];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //! app UI
    self.navigationController.navigationBar.barTintColor = [UIColor redColor];
    self.navigationController.navigationBar.tintColor = [UIColor redColor];
    self.navigationController.navigationBar.translucent = NO;
    self.navigationController.navigationBar.titleTextAttributes = @{NSFontAttributeName : [UIFont boldSystemFontOfSize:15],
                                                                    NSForegroundColorAttributeName:[UIColor redColor]};
    [self addCancelButton];
    self.activitiIndecator.hidesWhenStopped = YES;
    
    [self.activitiIndecator startAnimating];
    
    //! clear previous info for settings
    NSHTTPCookieStorage *storage = [NSHTTPCookieStorage sharedHTTPCookieStorage];
    for (NSHTTPCookie *cookie in [storage cookies]) {
        [storage deleteCookie:cookie];
    }
    [[NSUserDefaults standardUserDefaults] synchronize];
    //!
    
    switch (self.type) {
        case SocialTypeLinkedIn:
            self.title = @"LinkedIn";
            break;
        case SocialTypeTwitter:
            self.title = @"Twitter";
            break;
        case SocialTypeInstagram:
            self.title = @"Instagram";
            break;
        case SocialTypeYouTube:
            self.title = @"YouTube";
            break;
        default:
            break;
    }
    
    //! end app UI
    self.webView.delegate = self;
    
    if (!self.isOAUTH2) {
        //! SocialTypeTwitter
        if (self.type == SocialTypeTwitter) {
            OauthRequestManager *manager = [[OauthRequestManager alloc] initWithURL:self.socialRequestTokenURL tocken:nil key:self.key secret:self.secret verification:nil redirectUrl:self.redirect];
            __weak typeof (self) wSelf = self;
            [manager startRequestWithSucces:^(NSString *httpBody, NSDictionary *data) {
                NSArray *components = [httpBody componentsSeparatedByString:@"&"];

                NSString *oauthToken = nil;
                NSString *oauthTokenSecret = nil;

                for (NSString *values in components) {
                    if ([values rangeOfString:@"oauth_token="].length) {
                        oauthToken = [values stringByReplacingOccurrencesOfString:@"oauth_token=" withString:@""];
                    }
                    if ([values rangeOfString:@"oauth_token_secret="].length) {
                        oauthTokenSecret = [values stringByReplacingOccurrencesOfString:@"oauth_token_secret=" withString:@""];
                    }
                }

                NSString *address = [NSString stringWithFormat:
                                     @"https://api.twitter.com/oauth/authorize?oauth_token=%@",
                                     oauthToken];

                NSURL *url = [NSURL URLWithString:address];
                NSURLRequest *request = [NSURLRequest requestWithURL:url];
                [wSelf.webView loadRequest:request];
            } failure:^(NSError *error) {
                //! error
            }];
        }
    } else {
        //! SocialTypeLinkedIn & SocialTypeInstagram
        if (self.type == SocialTypeLinkedIn ||
            self.type == SocialTypeInstagram) {
            
            NSMutableString *args = self.socialAuthorizeTokenURL.mutableCopy;
            [args appendFormat:@"?response_type=%@", @"code"];
            
            if (self.key) {
                [args appendFormat:@"&client_id=%@", self.key];
            }
            if (self.redirect) {
                [args appendFormat:@"&redirect_uri=%@", self.redirect];
            }
            
            if (self.type == SocialTypeLinkedIn) {
                [args appendFormat:@"&state=%@", @(987654321)];
                [args appendFormat:@"&scope=%@", @"r_basicprofile"];
            }
            
            NSURL *url = [NSURL URLWithString:args];
            NSURLRequest *request = [NSURLRequest requestWithURL:url];
            [self.webView loadRequest:request];
        }
        
        //! SocialTypeYouTube
        if (self.type == SocialTypeYouTube) {
            NSDictionary *dictionary = [NSDictionary dictionaryWithObjectsAndKeys:@"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36", @"UserAgent", nil];
            [[NSUserDefaults standardUserDefaults] registerDefaults:dictionary];
            NSString *authenticateURLString = [NSString stringWithFormat:@"%@?client_id=%@&response_type=code&state=%@&scope=%@&redirect_uri=%@&access_type=%@&approval_prompt=force", self.socialAuthorizeTokenURL, self.key, @"BladerFeed", @"https://www.googleapis.com/auth/youtube.readonly", self.redirect, @"offline"];
            NSURL *url = [NSURL URLWithString:authenticateURLString];
            NSURLRequest *request = [NSURLRequest requestWithURL:url];
            [self.webView loadRequest:request];
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

#pragma mark - Actions

- (void)cancelAction {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)addCancelButton {
    UIBarButtonItem *cancelButton = [[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonItemStylePlain target:self action:@selector(cancelAction)];
    self.navigationItem.rightBarButtonItem = cancelButton;
}

#pragma mark -  UIWebViewDelegate

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType  {
    if (!self.isOAUTH2) {
        //! Twitter
        if (self.type == SocialTypeTwitter) {
            //! cancel action
            if ([request.URL.absoluteString rangeOfString:self.redirect].length > 0) {
                
                if ([request.URL.absoluteString rangeOfString:@"denied"].length > 0) {
                    [self dismissViewControllerAnimated:YES completion:nil];
                    return NO;
                }
                
                NSArray *arurlParts = [request.URL.absoluteString componentsSeparatedByString:@"?"];
                NSArray *pairs = [arurlParts[1] componentsSeparatedByString:@"&"];
                
                for (NSString *pair in pairs) {
                    NSArray *elements = [pair componentsSeparatedByString:@"="];
                    if ([[elements objectAtIndex:0] isEqualToString:@"oauth_token"]) {
                        self.authT = [elements objectAtIndex:1];
                    } else if ([[elements objectAtIndex:0] isEqualToString:@"oauth_token_secret"]) {
                    } else if ([[elements objectAtIndex:0] isEqualToString:@"oauth_session_handle"]) {
                    } else if ([[elements objectAtIndex:0] isEqualToString:@"oauth_token_duration"]) {
                    } else if ([[elements objectAtIndex:0] isEqualToString:@"oauth_verifier"]) {
                        self.authVerif = [elements objectAtIndex:1];
                    } else if ([[elements objectAtIndex:0] isEqualToString:@"oauth_token_attributes"]) {
                    } else if ([[elements objectAtIndex:0] isEqualToString:@"oauth_token_renewable"]) {
                    }
                }
                
                OauthRequestManager *manager = [[OauthRequestManager alloc] initWithURL:self.socialAccessTokenURL tocken:self.authT key:self.key secret:self.secret verification:self.authVerif redirectUrl:self.redirect];
        
                [manager startRequestWithSucces:^(NSString *httpBody, NSDictionary *data) {
                    
                    NSArray *components = [httpBody componentsSeparatedByString:@"&"];
                    NSString *userName = @"";
                    
                    for (NSString *str in components) {
                        if ([str rangeOfString:@"screen_name="].length > 0) {
                            NSArray *components2 = [str componentsSeparatedByString:@"="];
                            userName = components2.lastObject;
                        }
                    }
                    
                    //! @"https://twitter.com/%@"
                    self.callBackURL([NSString stringWithFormat:@"https://twitter.com/%@", userName], NO, self);
                } failure:^(NSError *error) {
                    if (self.callBackURL) {
                        self.callBackURL(nil, YES, self);
                    }
                }];
                return NO;
            }
            
            return YES;
        }
        return YES;
    } else {
        
        //! errors
        NSString *errorStr = [NSString stringWithFormat:@"%@/?error=", self.redirect];
        if ([request.URL.absoluteString rangeOfString:errorStr].length > 0) {
            if (self.callBackURL) {
                self.callBackURL(nil, YES, self);
            }
            return NO;
        }
        //! LinkedIn
        if (self.type == SocialTypeLinkedIn) {
            
            NSString *redIS = [NSString stringWithFormat:@"%@?code=", self.redirect];
            
            if ([request.URL.absoluteString rangeOfString:redIS].length > 0) {
                NSString *orig = [request.URL.absoluteString stringByReplacingOccurrencesOfString:redIS withString:@""];
                NSArray *sepArr = [orig componentsSeparatedByString:@"&"];
                NSString *code = sepArr.firstObject;
                [self performOauth2AuthRequestWithCode:code completion:^(NSString *info, NSError *error) {
                    //! info
                    if (error) {
                        if (self.callBackURL) {
                            self.callBackURL(nil, YES, self);
                        }
                        return;
                    }
                    if (info) {
                        [self performLinkedinOauthWithOauth:info completion:^(NSString *url, NSError *error){
                            if (error) {
                                if (self.callBackURL) {
                                    self.callBackURL(nil, YES, self);
                                }
                                return;
                            }
                            if (self.callBackURL) {
                                self.callBackURL(url, NO, self);
                            }
                        }];
                    }
                }];
            }
        }
        //! Instagram
        else if (self.type == SocialTypeInstagram) {
            NSString *redIS = [NSString stringWithFormat:@"%@/?code=", self.redirect];
            
            if ([request.URL.absoluteString rangeOfString:redIS].length > 0) {
 
                NSString *orig = [request.URL.absoluteString stringByReplacingOccurrencesOfString:redIS withString:@""];
                NSArray *sepArr = [orig componentsSeparatedByString:@"&"];
                NSString *code = sepArr.firstObject;
                [self performOauth2AuthRequestWithCode:code completion:^(NSString *userName, NSError *error) {
                    //! info
                    if (error) {
                        if (self.callBackURL) {
                            self.callBackURL(nil, YES, self);
                        }
                        return;
                    }
                    if (userName) {
                        //! @"https://www.instagram.com/%@/"
                        self.callBackURL([NSString stringWithFormat:@"https://www.instagram.com/%@/", userName], NO, self);

                    }
                }];

            }
        }
        //! YouTube
        if (self.type == SocialTypeYouTube) {
            NSString *redIS = [NSString stringWithFormat:@"%@?state=BladerFeed&code=", self.redirect];
            if ([request.URL.absoluteString rangeOfString:redIS].length > 0) {
                NSString *orig = [request.URL.absoluteString stringByReplacingOccurrencesOfString:redIS withString:@""];
                NSArray *sepArr = [orig componentsSeparatedByString:@"&"];
                NSString *code = sepArr.firstObject;
                
                [self performOauth2GoogleToken:code completion:^(NSString *url, NSError *error) {
                    if (error) {
                        if (self.callBackURL) {
                            self.callBackURL(nil, YES, self);
                        }
                        return;
                    }
                    if (url) {
                        self.callBackURL(url, NO, self);
                    }
                }];
            }
        }
        
        return YES;
    }
}

- (void)webViewDidStartLoad:(UIWebView *)webView {
    [self.activitiIndecator startAnimating];
}

- (void)webViewDidFinishLoad:(UIWebView *)webView {
    [self.activitiIndecator stopAnimating];
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
    if (error) {
        
    }
}

#pragma mark - LinkedIN & Instagram

- (void)performOauth2AuthRequestWithCode:(NSString *)code completion:(void(^)(NSString *info, NSError *error))completion {
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:self.socialAccessTokenURL]];
    [request setHTTPMethod:@"POST"];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    
    NSString *datInfo = [NSString stringWithFormat:@"grant_type=authorization_code&code=%@&redirect_uri=%@&client_id=%@&client_secret=%@", code, self.redirect, self.key, self.secret];
    
    NSData *bodyData = [datInfo dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    [request setValue:[NSString stringWithFormat:@"%lu", (unsigned long)[bodyData length]] forHTTPHeaderField:@"Content-Length"];
    [request setHTTPBody:bodyData];
    
    NSURLSessionConfiguration *config =  [NSURLSessionConfiguration defaultSessionConfiguration];
    NSURLSession *sess = [NSURLSession sessionWithConfiguration:config];
    
    NSURLSessionDataTask *task = [sess dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        NSString* httpBody = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        if ([httpBody rangeOfString:@"access_token"].length > 0) {
            NSMutableDictionary *accessData = [NSJSONSerialization JSONObjectWithData:data options:1 error:nil];

            if (completion) {
                if (self.type == SocialTypeInstagram) {
                    completion(accessData[@"user"][@"username"], nil);
                } else {
                    completion(accessData[@"access_token"], nil);
                }
            }
        } else {
            if (completion) {
                completion(nil, [NSError errorWithDomain:@"intros.error" code:10091 userInfo:@{NSLocalizedDescriptionKey : @"stopped"}]);
            }
        }
    }];
    
    [task resume];

}

- (void)performLinkedinOauthWithOauth:(NSString *)oauth
                           completion:(void(^)(NSString *url, NSError *error))completion {
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"https://api.linkedin.com/v1/people/~?format=json"]];
    [request setHTTPMethod:@"GET"];

    [request setValue:@"api.linkedin.com" forHTTPHeaderField:@"Host"];
    [request setValue:@"Keep-Alive" forHTTPHeaderField:@"Connection"];
    [request setValue:[NSString stringWithFormat:@"Bearer %@", oauth] forHTTPHeaderField:@"Authorization"];
    NSURLSessionConfiguration *config =  [NSURLSessionConfiguration defaultSessionConfiguration];
    NSURLSession *sess = [NSURLSession sessionWithConfiguration:config];
    
    NSURLSessionDataTask *task = [sess dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        NSString* httpBody = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        if ([httpBody rangeOfString:@"siteStandardProfileRequest"].length > 0) {
            NSMutableDictionary *accessData = [NSJSONSerialization JSONObjectWithData:data options:1 error:nil];
            //! Linkedin;
            if (completion) {
                completion([accessData[@"siteStandardProfileRequest"] valueForKey:@"url"], nil);
            }
        } else {
            if (completion) {
                completion(nil, [NSError errorWithDomain:@"intros.error" code:10091 userInfo:@{NSLocalizedDescriptionKey : @"stopped"}]);
            }
        }
        
    }];
    
    [task resume];

}

#pragma mark - Google & YouTube

- (void)performOauth2GoogleToken:(NSString *)code
                      completion:(void(^)(NSString *url, NSError *error))completion {
    
    NSString *post = [NSString stringWithFormat:@"code=%@&client_id=%@&client_secret=%@&redirect_uri=%@&grant_type=authorization_code", code, self.key, self.secret, self.redirect];
    NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    NSString *postLength = [NSString stringWithFormat:@"%lu", (unsigned long)[post length]];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:self.socialAccessTokenURL]];
    [request setHTTPMethod:@"POST"];
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    [request setHTTPBody:postData];
    
    NSURLSessionConfiguration *config =  [NSURLSessionConfiguration defaultSessionConfiguration];
    NSURLSession *sess = [NSURLSession sessionWithConfiguration:config];
    
    NSURLSessionDataTask *task = [sess dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        NSString* httpBody = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        if ([httpBody rangeOfString:@"access_token"].length > 0) {
            NSMutableDictionary *accessData = [NSJSONSerialization JSONObjectWithData:data options:1 error:nil];
            [self getChanelsListWithTocken:accessData[@"access_token"] completion:^(NSString *urlStr, NSError *error) {
                if (!error) {
                    if (completion) {
                        completion(urlStr, nil);
                    }
                } else {
                    if (completion) {
                        completion(nil, [NSError errorWithDomain:@"intros.error" code:10091 userInfo:@{NSLocalizedDescriptionKey : @"stopped"}]);
                    }
                }
            }];
        } else {
            if (completion) {
                completion(nil, [NSError errorWithDomain:@"intros.error" code:10091 userInfo:@{NSLocalizedDescriptionKey : @"stopped"}]);
            }
        }
        
    }];
    
    [task resume];
}

//! https://www.googleapis.com/youtube/v3
//! get youtube chanels
- (void)getChanelsListWithTocken:(NSString *)token
                      completion:(void(^)(NSString *urlStr, NSError *error))completion {
    
    NSString *channels = @"https://www.googleapis.com/youtube/v3/channels?mine=true&part=snippet,contentDetails,statistics";
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:channels]];
    [request setHTTPMethod:@"GET"];
    [request setValue:[NSString stringWithFormat:@"Bearer %@", token] forHTTPHeaderField:@"Authorization"];
    
    NSURLSessionConfiguration *config =  [NSURLSessionConfiguration defaultSessionConfiguration];
    NSURLSession *sess = [NSURLSession sessionWithConfiguration:config];
    
    NSURLSessionDataTask *task = [sess dataTaskWithRequest:request completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        NSString* httpBody = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        if ([httpBody rangeOfString:@"items"].length > 0) {
            
            NSMutableDictionary *accessData = [NSJSONSerialization JSONObjectWithData:data options:1 error:nil];
            
            //! https://www.youtube.com/channel/
            if ([accessData[@"items"] isKindOfClass:[NSArray class]]) {
                NSArray *items = accessData[@"items"];
                
                NSString *chanelSTR = [NSString stringWithFormat:@"https://www.youtube.com/channel/%@",items.firstObject[@"id"]];
                if (completion) {
                    completion(chanelSTR, nil);
                }
            } else {
                
            }
        } else {
            if (completion) {
                completion(nil, [NSError errorWithDomain:@"intros.error" code:10091 userInfo:@{NSLocalizedDescriptionKey : @"stopped"}]);
            }
        }
    }];
    
    [task resume];

}

@end
