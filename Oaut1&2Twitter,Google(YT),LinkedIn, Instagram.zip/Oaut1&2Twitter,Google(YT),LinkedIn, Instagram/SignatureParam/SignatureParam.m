#import "SignatureParam.h"

@implementation SignatureParam
- (instancetype)initWithN:(NSString *)n v:(NSString *)v {
    if (self = [super init]) {
        self.neme = n;
        self.value = v;
    }
    return self;
}

- (NSString *)description {
    return self.neme;
}
@end
