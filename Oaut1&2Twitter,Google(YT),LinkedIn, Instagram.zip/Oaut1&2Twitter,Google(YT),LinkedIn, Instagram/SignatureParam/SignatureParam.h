#import <Foundation/Foundation.h>

@interface SignatureParam : NSObject

@property (strong, nonatomic) NSString *neme;
@property (strong, nonatomic) NSString *value;

- (instancetype)initWithN:(NSString *)n v:(NSString *)v;

@end
