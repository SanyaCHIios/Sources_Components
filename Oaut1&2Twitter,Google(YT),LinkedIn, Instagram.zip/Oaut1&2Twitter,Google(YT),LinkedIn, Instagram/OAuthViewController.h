#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, SocialType) {
    SocialTypeTwitter,
    SocialTypeLinkedIn,
    SocialTypeInstagram,
    SocialTypeYouTube
};

@interface OAuthViewController : UIViewController

@property (copy, nonatomic) void (^callBackURL)(NSString *url, BOOL isError, OAuthViewController *control);

- (instancetype)initWithRequestOautTokenURL:(NSString *)requestTURL
                               authTURL:(NSString *)authTURL
                             accessTURL:(NSString *)accessTURL
                                    key:(NSString *)key
                                 secret:(NSString *)secret
                               redirect:(NSString *)redirect
                                   type:(SocialType)type;

- (instancetype)initWithRequestOaut2authTURL:(NSString *)authTURL
                             accessTURL:(NSString *)accessTURL
                                    key:(NSString *)key
                                 secret:(NSString *)secret
                               redirect:(NSString *)redirect
                                   type:(SocialType)type;
@end
