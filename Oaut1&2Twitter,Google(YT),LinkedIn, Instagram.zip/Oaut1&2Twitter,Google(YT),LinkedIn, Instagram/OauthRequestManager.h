#import <Foundation/Foundation.h>

@interface OauthRequestManager : NSObject

@property (assign,nonatomic) BOOL isOAUTH2;

- (instancetype)initWithURL:(NSString *)mainURL
                     tocken:(NSString *)tocken
                        key:(NSString *)key
                     secret:(NSString *)secret
               verification:(NSString *)verif
                redirectUrl:(NSString *)redirect;

- (void)startRequestWithSucces:(void(^)(NSString *, NSDictionary *))success
                       failure:(void(^)(NSError *))failure;
@end
