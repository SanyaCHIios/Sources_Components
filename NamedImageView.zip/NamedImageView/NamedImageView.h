#import <UIKit/UIKit.h>

@interface NamedImageView : UIImageView
@property (strong, nonatomic) NSString *shortName;
@property (strong, nonatomic) IBInspectable UIColor *bgCollor;
@property (strong, nonatomic) IBInspectable UIColor *shortNameColor;
@end
