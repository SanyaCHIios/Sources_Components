
#import "NamedImageView.h"
#import "Constants.h"

@interface NamedImageView ()
@property (strong, nonatomic) UILabel *textInfo;
@end

@implementation NamedImageView

- (void)dealloc {
    DLog(@"<<< --- >>> NamedImageView DEALLOC");
}

- (void)setShortName:(NSString *)shortName {
    _shortName = shortName;
    
    [self updateBGStyle];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self updateBGStyle];
}

- (void)setImage:(UIImage *)image {
    [super setImage:image];
    [self updateBGStyle];
}
#pragma mark - Custome behavior

- (void)updateBGStyle {
    self.backgroundColor = RGB(225, 225, 225);
    if (self.layer.cornerRadius != CGRectGetHeight(self.bounds)/2) {
        self.clipsToBounds = YES;
        self.layer.cornerRadius = CGRectGetHeight(self.bounds)/2;
        
        [self.textInfo removeFromSuperview];
        self.textInfo = nil;
    }
    
    if (self.image) {
        self.backgroundColor = [UIColor whiteColor];
        [self.textInfo removeFromSuperview];
        self.textInfo = nil;
        return;
    }
    
    if (self.shortName.length) {
        if (self.textInfo == nil) {
            self.textInfo = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(self.frame), CGRectGetHeight(self.frame))];
            
            if (self.shortNameColor) self.textInfo.textColor = self.shortNameColor;
            else self.textInfo.textColor = [UIColor whiteColor];
            
            self.textInfo.minimumScaleFactor = 0.5;
            
            [self addSubview:self.textInfo];
            
            self.textInfo.font = [UIFont systemFontOfSize:([self minFontSizeFromSize:[UIFont systemFontOfSize:CGRectGetHeight(self.bounds)/2].pointSize] - 2)];
            self.textInfo.textAlignment = NSTextAlignmentCenter;
        }
        self.textInfo.text = self.shortName;
    } else {
        [self.textInfo removeFromSuperview];
        self.textInfo = nil;
        return;
    }
}

- (CGFloat)minFontSizeFromSize:(CGFloat)size {
    
    CGFloat width = CGRectGetWidth([UIScreen mainScreen].bounds);
    
    UIFont *defFont = [UIFont systemFontOfSize:size];
    CGFloat contentHeight = 0;
    
    CGRect rect = [self.shortName boundingRectWithSize:CGSizeMake(CGFLOAT_MAX, self.frame.size.height) options:NSLineBreakByWordWrapping | NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:defFont} context:nil];
    contentHeight += rect.size.width + defFont.pointSize/2;
    
    if (contentHeight > width && size > [UIFont systemFontOfSize:CGRectGetHeight(self.bounds)/2].pointSize) {
        return [self minFontSizeFromSize:size-1];
    }
    
    return size;
}


@end
